"""Pruebas del Gran Reto (Python puro, sin ROS). Mismo estilo que test_logic.py."""
import numpy as np
from types import SimpleNamespace as NS

from arm_broker import ik
from arm_broker.admission import Limits
from arm_broker.kinematics import fk
from arm_broker.pick_place import Mesa, PlanificadorPick, validar_orden

MESA = Mesa.desde_params(
    ['rojo:cubo:200:100:20', 'verde:cilindro:200:-100:20', 'azul:esfera:230:0:20'],
    ['A:100:-200:30', 'C:-100:-200:30'])


def orden(**kw):
    base = dict(accion='recoger_y_colocar', objeto='cubo', color='rojo', zona='A',
                permitido=True, causa_decision='')
    base.update(kw)
    return NS(**base)


def test_no_permitida_se_rechaza_con_causa():
    ok, code, msg, _ = validar_orden(orden(permitido=False, causa_decision='tira'), MESA)
    assert not ok and code == 'NO_PERMITIDO' and 'tira' in msg


def test_objeto_ausente_ambiguo_y_zona():
    assert validar_orden(orden(color='negro'), MESA)[1] == 'OBJETO_AUSENTE'
    assert validar_orden(orden(color='rojo', objeto='esfera'), MESA)[1] == 'OBJETO_AUSENTE'
    assert validar_orden(orden(color='ninguno', objeto='ninguno'), MESA)[1] == 'OBJETO_NO_INDICADO'
    assert validar_orden(orden(zona='ninguno'), MESA)[1] == 'ZONA_INVALIDA'
    assert validar_orden(orden(accion='desconocida'), MESA)[1] == 'ACCION_DESCONOCIDA'


def test_resuelve_color_por_objeto_unico():
    ok, _, _, color = validar_orden(orden(color='ninguno', objeto='esfera'), MESA)
    assert ok and color == 'azul'


def test_ik_ida_y_vuelta():
    lim, rng = Limits(), np.random.default_rng(3)
    bien = 0
    for _ in range(30):
        q = rng.uniform(lim.q_min * 0.6, lim.q_max * 0.6)
        T = fk(q)
        r = ik.resolver(T[:3, 3], q + rng.normal(0, 0.2, 6), lim.q_min, lim.q_max,
                        a_ref=T[:3, 0], eje=0)
        bien += r.ok and np.linalg.norm(fk(r.q)[:3, 3] - T[:3, 3]) < 1.0
    assert bien >= 28


def test_planificador_genera_secuencia_completa():
    lim = Limits()
    r = ik.resolver([200, 0, 60], [0, -0.5, 0.5, 0, 0.5, 0], lim.q_min, lim.q_max,
                    a_ref=[0, 0, -1], eje=0)
    pl = PlanificadorPick(MESA, lim, [0, -0.5, 0.5, 0, 0.5, 0], r.q, eje_aproximacion=0)
    p = pl.planear('rojo', 'A', r.q)
    assert p.ok
    assert [n for n, _, _ in p.pasos] == ['aproximacion_objeto', 'agarre', 'elevacion',
                                          'aproximacion_zona', 'deposito', 'retirada', 'inicio']
    assert [g for _, _, g in p.pasos if g] == ['abrir', 'cerrar', 'abrir']
    q_dep = dict((n, q) for n, q, _ in p.pasos)['deposito']
    assert np.linalg.norm(fk(q_dep)[:3, 3] - np.array(p.destino_mm)) < 1.0


def test_inalcanzable_se_informa():
    lim = Limits()
    mesa = Mesa.desde_params(['rojo:cubo:900:0:20'], ['A:100:-200:30'])
    pl = PlanificadorPick(mesa, lim, [0, -0.5, 0.5, 0, 0.5, 0], [0, -0.5, 0.5, 0, 0.5, 0])
    p = pl.planear('rojo', 'A', [0, -0.5, 0.5, 0, 0.5, 0])
    assert not p.ok and 'aproximacion_objeto' in p.motivo
