"""Logica de la orden 'recoger y colocar' (Gran Reto). Python puro, sin ROS.

 validar_orden()      -> admision de la decision tipada (usa el MISMO portero del RB-2:
                         se llama desde el goal_callback, antes de encolar)
 PlanificadorPick     -> convierte (objeto, zona) en una secuencia de waypoints
                         articulares usando la IK sobre la FK del RB-2
Unidades: milimetros (igual que kinematics.fk) y radianes.
"""
import time
from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional, Tuple

import numpy as np

from . import ik
from .admission import Limits, validate
from .kinematics import fk

ACCION_RECOGER = 'recoger_y_colocar'
ACCION_INICIO = 'ir_inicio'
NINGUNO = 'ninguno'


@dataclass
class Mesa:
    objetos: Dict[str, Tuple[str, float, float, float]]   # color -> (objeto, x, y, z)
    zonas: Dict[str, Tuple[float, float, float]]          # zona  -> (x, y, z)

    @staticmethod
    def desde_params(objetos: List[str], zonas: List[str]) -> 'Mesa':
        """'color:objeto:x:y:z' (mm) y 'zona:x:y:z' (mm), en el marco de la base."""
        obj = {}
        for s in objetos:
            c, o, x, y, z = s.split(':')
            obj[c] = (o, float(x), float(y), float(z))
        zon = {}
        for s in zonas:
            n, x, y, z = s.split(':')
            zon[n] = (float(x), float(y), float(z))
        return Mesa(obj, zon)

    def resolver_objeto(self, color: str, objeto: str):
        """-> (ok, codigo, motivo, color_resuelto)."""
        if color != NINGUNO:
            if color not in self.objetos:
                return False, 'OBJETO_AUSENTE', f"no hay ningun objeto en la posicion '{color}' de la mesa", ''
            if objeto not in (NINGUNO, self.objetos[color][0]):
                return (False, 'OBJETO_AUSENTE',
                        f"en la posicion '{color}' no hay '{objeto}' (ahi esta el "
                        f"'{self.objetos[color][0]}')", '')
            return True, 'OK', '', color
        if objeto == NINGUNO:
            return False, 'OBJETO_NO_INDICADO', 'la orden no indica que objeto recoger', ''
        cand = [c for c, v in self.objetos.items() if v[0] == objeto]
        if len(cand) != 1:
            return (False, 'OBJETO_AUSENTE' if not cand else 'OBJETO_AMBIGUO',
                    f"objeto '{objeto}' " + ('ausente de la mesa' if not cand
                                             else 'ambiguo: indica la posicion'), '')
        return True, 'OK', '', cand[0]


def validar_orden(o, mesa: Mesa):
    """Admision de la decision tipada. `o` tiene accion/objeto/color/zona/permitido/
    causa_decision. Devuelve (ok, codigo, motivo, color_resuelto)."""
    if not o.permitido:                                    # <<< regla del examen
        return (False, 'NO_PERMITIDO',
                f"orden no permitida ({o.causa_decision or 'sin detalle'})", '')
    if o.accion == ACCION_INICIO:
        return True, 'OK', '', ''
    if o.accion != ACCION_RECOGER:
        return False, 'ACCION_DESCONOCIDA', f"accion no reconocida: '{o.accion}'", ''
    ok, code, msg, color = mesa.resolver_objeto(o.color, o.objeto)
    if not ok:
        return False, code, msg, ''
    if o.zona not in mesa.zonas:
        return False, 'ZONA_INVALIDA', f"zona de destino invalida o no indicada: '{o.zona}'", ''
    return True, 'OK', '', color


@dataclass
class Plan:
    ok: bool
    motivo: str = ''
    pasos: list = field(default_factory=list)   # (nombre, q[6], gripper_despues)
    destino_mm: Optional[Tuple[float, float, float]] = None
    ik_ms: float = 0.0
    plan_ms: float = 0.0


class PlanificadorPick:
    def __init__(self, mesa: Mesa, lim: Limits, q_inicio, q_agarre_ref,
                 mantener_orientacion=True, eje_aproximacion=0, z_aprox_mm=60.0,
                 dz_agarre_mm=0.0, dz_dejar_mm=10.0):
        self.mesa, self.q_inicio = mesa, np.asarray(q_inicio, float)
        self.q_ref = np.asarray(q_agarre_ref, float)
        # los limites de PASO no aplican a trayectorias internas del worker
        self.lim = replace(lim, max_step=1e9)
        # direccion de aproximacion = la que tiene el efector en la pose de agarre ensenada
        self.eje = int(eje_aproximacion)
        self.a_ref = fk(self.q_ref)[:3, self.eje] if mantener_orientacion else None
        self.z_aprox, self.dz_agarre, self.dz_dejar = z_aprox_mm, dz_agarre_mm, dz_dejar_mm

    def _ik(self, p, semillas):
        return ik.resolver_multi(p, semillas, self.lim.q_min, self.lim.q_max,
                                 a_ref=self.a_ref, eje=self.eje)

    def planear(self, color: str, zona: str, q_actual, pos_objeto=None) -> Plan:
        """pos_objeto: (x,y,z) mm de la camara; si es None se usa el catalogo."""
        t0 = time.perf_counter()
        _, ox, oy, oz = self.mesa.objetos[color]
        if pos_objeto is not None:
            ox, oy, oz = pos_objeto
        zx, zy, zz = self.mesa.zonas[zona]
        agarre = np.array([ox, oy, oz + self.dz_agarre])
        dejar = np.array([zx, zy, zz + self.dz_dejar])
        up = np.array([0.0, 0.0, self.z_aprox])
        objetivos = [('aproximacion_objeto', agarre + up, 'abrir'),
                     ('agarre', agarre, 'cerrar'),
                     ('elevacion', agarre + up, None),
                     ('aproximacion_zona', dejar + up, None),
                     ('deposito', dejar, 'abrir'),
                     ('retirada', dejar + up, None)]
        pasos, q_prev, t_ik = [], np.asarray(q_actual, float), 0.0
        for nombre, p, grip in objetivos:
            t1 = time.perf_counter()
            r = self._ik(p, [q_prev, self.q_ref, self.q_inicio])
            t_ik += (time.perf_counter() - t1) * 1000.0
            if not r.ok:
                return Plan(False, f"IK sin solucion en '{nombre}' ({p[0]:.0f},{p[1]:.0f},"
                                   f"{p[2]:.0f}) mm: error {r.err_pos_mm:.1f} mm / "
                                   f"{r.err_rot_rad:.2f} rad", ik_ms=t_ik)
            ok, code, msg = validate(r.q, r.q, self.lim)       # limites articulares + workspace
            if not ok:
                return Plan(False, f"'{nombre}' no es admisible: {code} {msg}", ik_ms=t_ik)
            pasos.append((nombre, r.q, grip))
            q_prev = r.q
        pasos.append(('inicio', self.q_inicio.copy(), None))
        total = (time.perf_counter() - t0) * 1000.0
        return Plan(True, '', pasos, (float(dejar[0]), float(dejar[1]), float(dejar[2])),
                    ik_ms=t_ik, plan_ms=max(total - t_ik, 0.0))

    def diagnostico_alcance(self) -> List[str]:
        """Avisos al arrancar: que objetos/zonas no se pueden alcanzar con la orientacion
        de agarre configurada (calibra q_agarre_ref si salen todos)."""
        avisos = []
        for c in self.mesa.objetos:
            for z in list(self.mesa.zonas)[:1]:
                p = self.planear(c, z, self.q_ref)
                if not p.ok:
                    avisos.append(f"objeto '{c}': {p.motivo}")
        for z in self.mesa.zonas:
            c = next(iter(self.mesa.objetos))
            p = self.planear(c, z, self.q_ref)
            if not p.ok and f"zona '{z}'" not in ' '.join(avisos):
                avisos.append(f"zona '{z}': {p.motivo}")
        return avisos
