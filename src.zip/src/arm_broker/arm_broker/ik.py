"""Cinematica inversa NUMERICA sobre la FK del RB-2 (kinematics.fk). Sin ROS.

Minimos cuadrados amortiguados (DLS) con Jacobiano por diferencias finitas:
    dq = J^T (J J^T + lambda^2 I)^-1 e
Resuelve posicion (mm) y, opcionalmente, ALINEA el eje de aproximacion del efector
con una direccion `a_ref` (p. ej. hacia la mesa). El giro alrededor de ese eje queda
LIBRE: para agarrar basta que el gripper apunte hacia abajo; exigir tambien el
mismo giro en todos los puntos haria inalcanzable media mesa.
Parte de una semilla, asi que devuelve la solucion de codo mas cercana a la
configuracion actual (menor movimiento articular).
"""
import math
from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

from .kinematics import fk


@dataclass
class ResultadoIK:
    q: np.ndarray
    ok: bool
    err_pos_mm: float
    err_rot_rad: float
    iteraciones: int


def _residuo(q, p, a_ref, eje, w_rot):
    T = fk(q)
    e = [p - T[:3, 3]]
    if a_ref is not None:
        # cross(a_actual, a_ref) = 0 cuando el eje de aproximacion apunta a a_ref
        e.append(np.cross(T[:3, eje], a_ref) * w_rot)    # w_rot: mm por rad
    return np.concatenate(e), T


def resolver(p_mm: Sequence[float], q_semilla: Sequence[float], q_min, q_max,
             a_ref: Optional[Sequence[float]] = None, eje: int = 0, w_rot: float = 80.0,
             tol_pos: float = 0.5, tol_rot: float = 0.03, max_iter: int = 200,
             lam: float = 0.05, paso_max: float = 0.3) -> ResultadoIK:
    p = np.asarray(p_mm, float)
    a_ref = None if a_ref is None else np.asarray(a_ref, float) / np.linalg.norm(a_ref)
    q = np.clip(np.asarray(q_semilla, float), q_min, q_max)
    n = 0
    for n in range(1, max_iter + 1):
        e, _ = _residuo(q, p, a_ref, eje, w_rot)
        ep = float(np.linalg.norm(e[:3]))
        er = float(np.linalg.norm(e[3:])) / w_rot if a_ref is not None else 0.0
        if ep <= tol_pos and er <= tol_rot:
            return ResultadoIK(q, True, ep, er, n)
        J = np.zeros((len(e), 6))
        h = 1e-6
        for i in range(6):
            dq = q.copy()
            dq[i] += h
            J[:, i] = (e - _residuo(dq, p, a_ref, eje, w_rot)[0]) / h   # d(e)/dq = -dF/dq
        paso = J.T @ np.linalg.solve(J @ J.T + lam ** 2 * np.eye(len(e)), e)
        m = float(np.abs(paso).max())
        if m > paso_max:
            paso *= paso_max / m
        q = np.clip(q + paso, q_min, q_max)
    e, _ = _residuo(q, p, a_ref, eje, w_rot)
    ep = float(np.linalg.norm(e[:3]))
    er = float(np.linalg.norm(e[3:])) / w_rot if a_ref is not None else 0.0
    return ResultadoIK(q, ep <= tol_pos and er <= tol_rot, ep, er, n)


def resolver_multi(p_mm, semillas, q_min, q_max, **kw) -> ResultadoIK:
    """Prueba varias semillas en orden; devuelve la primera que converge
    (o la de menor error si ninguna converge)."""
    mejor = None
    for s in semillas:
        r = resolver(p_mm, s, q_min, q_max, **kw)
        if r.ok:
            return r
        if mejor is None or r.err_pos_mm < mejor.err_pos_mm:
            mejor = r
    return mejor
