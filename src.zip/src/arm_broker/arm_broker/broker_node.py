"""arm_broker: unico nodo que publica en /joint_states.

  _goal_cb      (grupo reentrante)  portero: valida con la FK, rechaza con motivo
  _accepted_cb  (grupo reentrante)  SOLO encola
  _worker_tick  (grupo exclusivo)   desencola y ejecuta de a uno

Modo de ejecucion (parametro `driver`):
  sim   (por defecto) -> solo publica /joint_states, el brazo fisico NO se mueve
  real                -> ademas manda cada destino al brazo con pymycobot
                         (mismo estilo del taller Item 4: UN destino y espera is_moving)
"""
import csv
import math
import os
import threading
import time

import numpy as np
import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import String

from arm_broker_interfaces.action import MoveJoints, PickPlace
from arm_broker_interfaces.msg import QueueState

from .admission import Limits, validate
from .kinematics import fk
from .pick_place import Mesa, PlanificadorPick, validar_orden
from .policies import Entry, Scheduler

RATE = 20.0  # Hz de /joint_states durante un movimiento (solo simulacion)
NAMES = ['joint2_to_joint1', 'joint3_to_joint2', 'joint4_to_joint3',
         'joint5_to_joint4', 'joint6_to_joint5', 'joint6output_to_joint6']


class ArmBroker(Node):
    def __init__(self):
        super().__init__('arm_broker')
        for k, v in dict(policy='aging', aging_rate=0.05, max_queue=20, max_joint_vel=0.5,
                         initial_q=[0.0] * 6, joint_names=NAMES, r_max_mm=280.0,
                         z_min_mm=10.0, max_step=1.5, log_dir='.',
                         # ---- brazo real ----
                         driver='sim', puerto='/dev/ttyUSB0', baudios=1000000,
                         velocidad_robot=30, timeout_mov_s=25.0,
                         clase_driver='MyCobot').items():   # MyCobot | MyCobot280 | ...
            self.declare_parameter(k, v)
        p = lambda k: self.get_parameter(k).value  # noqa: E731

        self._sched = Scheduler(p('policy'), p('aging_rate'))
        self._max_queue, self._vmax, self._names = p('max_queue'), p('max_joint_vel'), list(p('joint_names'))
        self._lim = Limits(r_max=p('r_max_mm'), z_min=p('z_min_mm'), max_step=p('max_step'))
        self._cur_q = np.array(p('initial_q'), float)   # pose actual (solo la toca el worker)
        self._ref_q = self._cur_q.copy()                # referencia para "paso excesivo"
        self._lock, self._log_lock = threading.Lock(), threading.Lock()
        self._seq = self._n_acc = self._n_rej = self._n_done = 0
        self._active, self._by_uuid = None, {}
        self._mc = None                                  # handle pymycobot (None = simulacion)
        self._n_raw, self._extra_deg = 6, []             # ejes que reporta el brazo / extras fijos

        self._dir = p('log_dir')
        self._log('rechazos.csv', ['t_wall', 'client_id', 'priority', 'codigo', 'motivo'], 'w')
        self._log('goals_log.csv', ['seq', 'client_id', 'priority', 't_enq_wall', 'espera_s',
                                    'duracion_s', 'resultado'], 'w')

        self._init_pick(p)                                   # <<< Gran Reto (aditivo)
        self._conectar_brazo(p)                              # <<< brazo real (si driver:=real)
        accept_grp, worker_grp = ReentrantCallbackGroup(), MutuallyExclusiveCallbackGroup()
        self._js_pub = self.create_publisher(JointState, '/joint_states', 10)  # UNICO publicador
        self._qs_pub = self.create_publisher(QueueState, '/arm/queue_state', 10)
        self._rej_pub = self.create_publisher(String, '/arm/rejections', 10)
        self.create_timer(0.2, self._publicar_estado_real)
        ActionServer(self, MoveJoints, '/arm/move_joints', execute_callback=self._await_result,
                     goal_callback=self._goal_cb, handle_accepted_callback=self._accepted_cb,
                     cancel_callback=lambda gh: CancelResponse.ACCEPT, callback_group=accept_grp)
        # >>> Gran Reto: 2.a accion sobre la MISMA cola, el MISMO worker y el MISMO portero <<<
        ActionServer(self, PickPlace, '/arm/pick_place', execute_callback=self._await_result_pick,
                     goal_callback=self._goal_cb_pick, handle_accepted_callback=self._accepted_pick_cb,
                     cancel_callback=lambda gh: CancelResponse.ACCEPT, callback_group=accept_grp)
        self.create_timer(0.05, self._worker_tick, callback_group=worker_grp)
        self.create_timer(0.2, self._publish_queue_state, callback_group=accept_grp)  # 5 Hz
        self.get_logger().info(
            f'arm_broker listo | politica={self._sched.policy} | '
            f"driver={'REAL' if self._mc is not None else 'SIM'} | accion=/arm/move_joints")

    # ======================= BRAZO REAL (pymycobot) =======================
    def _conectar_brazo(self, p):
        """driver:=real -> abre el puerto y sincroniza la pose inicial con la REAL."""
        if p('driver') != 'real':
            self.get_logger().warn('driver=sim: el brazo FISICO NO se movera '
                                   '(usa -p driver:=real para moverlo)')
            return
        try:
            import pymycobot
            nombre = p('clase_driver')
            clase = getattr(pymycobot, nombre, None)
            if clase is None:                       # el taller Item 4 importaba desde .mycobot
                from pymycobot import mycobot as _m
                clase = getattr(_m, nombre)
        except (ImportError, AttributeError) as ex:
            raise RuntimeError(f"No se pudo cargar pymycobot.{p('clase_driver')}: {ex}") from ex
        self._mc = clase(p('puerto'), p('baudios'))
        time.sleep(1.0)
        raw = self._leer_raw_deg()
        if raw is None:
            self._mc = None
            raise RuntimeError('El brazo no responde. Revisa encendido, cable, puerto '
                               f"({p('puerto')}) y que ningun otro programa use el puerto.")
        self._n_raw = len(raw)
        if self._n_raw < 6:
            self._mc = None
            raise RuntimeError(f'get_angles() devolvio {self._n_raw} valores; se esperaban >= 6.')
        if self._n_raw > 6:
            # La FK/IK/portero modelan 6 ejes (kinematics.py). Los ejes extra NO se
            # planifican: se mantienen en el valor actual en cada comando.
            self.get_logger().warn(
                f'El brazo reporta {self._n_raw} ejes; la cinematica modela 6. '
                f'Los ejes {list(range(7, self._n_raw + 1))} se mantienen fijos en '
                f'{[round(v, 1) for v in raw[6:]]} deg')
        q_real = [math.radians(v) for v in raw[:6]]
        # la pose de partida del broker es la pose REAL (evita saltos y falsos "paso excesivo")
        self._cur_q = np.array(q_real, float)
        self._ref_q = self._cur_q.copy()
        self.get_logger().info(
            f"Driver REAL conectado en {p('puerto')} | {self._n_raw} ejes | "
            f'q real (deg) = {[round(v, 1) for v in raw]}')

    def _leer_raw_deg(self):
        """Lista COMPLETA de angulos (deg) que reporta el brazo, o None."""
        if self._mc is None:
            return None
        for _ in range(5):
            try:
                a = self._mc.get_angles()
            except Exception:
                a = None
            if a and a != -1 and len(a) >= 6:
                self._extra_deg = [float(v) for v in a[6:]]
                return [float(v) for v in a]
            time.sleep(0.2)
        return None

    def _fb_any(self, e, estado, progreso):
        """Feedback del tipo correcto segun la accion del goal (pick o move)."""
        if e.kind == 'pick':
            self._fb(e, estado, progreso)
        else:
            e.gh.publish_feedback(
                MoveJoints.Feedback(queue_position=0, state=estado, progress=float(progreso)))

    def _segmento_real(self, e, q1, estado, progreso0):
        """
        Ejecuta un waypoint articular en el brazo real.
        q1 está en radianes; pymycobot recibe grados.
        Devuelve True si se cancela y False si termina correctamente.
        Un timeout genera una excepción para no declarar éxito falso.
        """
        vel = int(self.get_parameter('velocidad_robot').value)
        timeout = float(self.get_parameter('timeout_mov_s').value)
    
        if not 1 <= vel <= 100:
            raise ValueError(f'velocidad_robot debe estar entre 1 y 100; recibido: {vel}')
    
        q1 = np.asarray(q1, dtype=float)
        if q1.shape != (6,) or not np.isfinite(q1).all():
            raise ValueError('El waypoint debe contener exactamente 6 ángulos finitos.')
    
        # IK: radianes -> grados para pymycobot.
        objetivo = [math.degrees(float(x)) for x in q1]
    
        # Conserva el mismo patrón de envío del taller: un destino por vez.
        respuesta = self._mc.send_angles(objetivo, vel)
        if respuesta == -1:
            raise RuntimeError('pymycobot rechazó el comando send_angles().')
    
        e.extra.setdefault('t_primer_mov', time.time())
    
        # Igual que el programa probado: dar tiempo al firmware para arrancar.
        time.sleep(1.0)
        t0 = time.monotonic()
        ultimo_estado = None
    
        while time.monotonic() - t0 < timeout:
            if e.gh.is_cancel_requested:
                try:
                    self._mc.stop()
                except Exception as ex:
                    self.get_logger().error(f'No se pudo detener el brazo: {ex!r}')
                return True
    
            self._fb_any(e, estado, progreso0)
    
            try:
                moviendo = self._mc.is_moving()
                if moviendo == 0:
                    ultimo_estado = 'terminado'
                    break
            except Exception as ex:
                self.get_logger().warn(f'Error leyendo is_moving(): {ex!r}')
    
            time.sleep(0.5)
    
        if ultimo_estado != 'terminado':
            try:
                self._mc.stop()
            except Exception:
                pass
            raise TimeoutError(
                f'El brazo no terminó el movimiento en {timeout:.1f} segundos.'
            )
    
        # Actualizar la pose con la lectura del hardware, no con el objetivo solicitado.
        q_real = self._leer_q_real()
        if q_real is None:
            raise RuntimeError(
                'El movimiento terminó, pero no se pudieron leer los ángulos reales.'
            )
    
        self._publish_joint_state(q_real)
        return False

    # ---- portero ----
    def _goal_cb(self, req):
        with self._lock:
            full, ref = len(self._sched) >= self._max_queue, self._ref_q.copy()
        if not req.client_id:
            return self._reject(req, 'NO_CLIENT', 'client_id vacio')
        if full:
            return self._reject(req, 'QUEUE_FULL', f'cola llena ({self._max_queue})')
        ok, code, msg = validate(list(req.q), ref, self._lim)
        return GoalResponse.ACCEPT if ok else self._reject(req, code, msg)

    def _reject(self, req, code, msg):
        with self._lock:
            self._n_rej += 1
        self.get_logger().warn(f'RECHAZADO [{req.client_id}] {code}: {msg}')
        self._log('rechazos.csv', [f'{time.time():.3f}', req.client_id, req.priority, code, msg])
        self._rej_pub.publish(String(data=f'{req.client_id}|{code}|{msg}'))
        return GoalResponse.REJECT

    # ---- encolado (NO ejecuta) ----
    def _accepted_cb(self, gh):
        r = gh.request
        with self._lock:
            self._seq += 1
            e = Entry(self._seq, r.client_id, int(r.priority), time.monotonic(),
                      [float(x) for x in r.q], t_wall=time.time(), gh=gh)
            self._by_uuid[bytes(gh.goal_id.uuid)] = e
            self._sched.push(e)
            self._ref_q, self._n_acc = np.array(e.q), self._n_acc + 1
        self.get_logger().info(f'encolado #{e.seq} [{e.client_id}] prio={e.priority}')

    # ---- worker unico ----
    def _worker_tick(self):
        with self._lock:
            e = self._active = self._sched.pop(time.monotonic())
        if e is None:
            return
        e.t_start = time.monotonic()
        e.gh.execute()  # dispara _await_result, que solo espera el resultado

        try:
            if e.gh.is_cancel_requested:
                e.outcome = 'canceled'
                e.message = 'cancelado antes de ejecutarse'
        
            elif e.kind == 'pick':
                e.outcome, e.message = self._run_pick_seguro(e)
        
            else:
                e.outcome, e.message = self._move_to(e)
        
        except TimeoutError as ex:
            e.outcome = 'aborted'
            e.message = f'timeout del brazo: {ex}'
            self.get_logger().error(f'#{e.seq} {e.message}')
        
        except Exception as ex:
            e.outcome = 'aborted'
            e.message = f'fallo del driver: {ex!r}'
            self.get_logger().error(f'#{e.seq} {e.message}')

        
        e.final_q = [float(x) for x in self._cur_q]
        with self._lock:
            self._active, self._n_done = None, self._n_done + 1
        self._log('goals_log.csv', [e.seq, e.client_id, e.priority, f'{e.t_wall:.3f}',
                                    f'{e.t_start - e.t_enq:.3f}',
                                    f'{time.monotonic() - e.t_start:.3f}', e.outcome])
        e.done.set()

    def _move_to(self, e):
        if self._mc is not None:                     # ---- brazo REAL ----
            canc = self._segmento_real(e, np.array(e.q, float), 'EXECUTING', 0.0)
            return (('canceled', 'cancelado durante la ejecucion') if canc
                    else ('succeeded', 'ok'))
        q0, q1 = self._cur_q.copy(), np.array(e.q)   # ---- simulacion ----
        n = max(int(np.abs(q1 - q0).max() / self._vmax * RATE), 2)
        fb = MoveJoints.Feedback(queue_position=0, state='EXECUTING')
        for i in range(1, n + 1):
            if e.gh.is_cancel_requested:
                return 'canceled', 'cancelado durante la ejecucion'
            self._publish_joint_state(q0 + (q1 - q0) * (0.5 - 0.5 * np.cos(np.pi * i / n)))
            fb.progress = i / n
            e.gh.publish_feedback(fb)
            time.sleep(1.0 / RATE)
        return 'succeeded', 'ok'

    def _publicar_estado_real(self):
        """Publica periodicamente los angulos reales si el driver esta conectado."""
        if self._mc is None:
            return
    
        try:
            q_real = self._leer_q_real()
            if q_real is not None:
                self._publish_joint_state(q_real)
        except Exception as ex:
            self.get_logger().warning(
                f'No se pudo publicar el estado real del brazo: {ex!r}'
            )
    
    def _publish_joint_state(self, q):
        """Unico punto del sistema que escribe en /joint_states (solo ROS; el brazo
        fisico se mueve en _segmento_real)."""
        self._cur_q = np.array(q)
        m = JointState(name=self._names, position=[float(x) for x in q])
        m.header.stamp = self.get_clock().now().to_msg()
        self._js_pub.publish(m)

    def _await_result(self, gh):
        """execute_callback: espera al worker y cierra el goal."""
        e = self._by_uuid.pop(bytes(gh.goal_id.uuid), None)
        res = MoveJoints.Result()
        if e is None:
            gh.abort()
            res.message = 'error interno'
            return res
        while not e.done.wait(0.1) and rclpy.ok():
            pass
        if gh.is_cancel_requested:
            gh.canceled()
        elif e.outcome == 'succeeded':
            gh.succeed()
        else:
            gh.abort()
        res.success = e.outcome == 'succeeded' and not gh.is_cancel_requested
        res.message, res.final_q = e.message, e.final_q
        return res

    # ======================= GRAN RETO: recoger y colocar (aditivo) =======================
    def _init_pick(self, p):
        for k, v in dict(
                mesa_objetos=['P1:cubo:200:100:20', 'P2:cilindro:200:-100:20',
                              'P3:esfera:230:0:20', 'P4:prisma:150:150:20'],
                mesa_zonas=['A:100:-200:30', 'B:0:-220:30', 'C:-100:-200:30'],
                pose_inicio=[0.0, -0.5, 0.5, 0.0, 0.5, 0.0],
                q_agarre_ref=[0.0, -0.5, 0.5, 0.0, 0.5, 0.0],   # CALIBRAR (ver README)
                eje_aproximacion=0, mantener_orientacion=True,
                z_aprox_mm=60.0, dz_agarre_mm=0.0, dz_dejar_mm=10.0,
                habilitar_gripper=False).items():
            self.declare_parameter(k, v)
        self._mesa = Mesa.desde_params(list(p('mesa_objetos')), list(p('mesa_zonas')))
        self._plan = PlanificadorPick(
            self._mesa, self._lim, p('pose_inicio'), p('q_agarre_ref'),
            mantener_orientacion=bool(p('mantener_orientacion')),
            eje_aproximacion=int(p('eje_aproximacion')), z_aprox_mm=p('z_aprox_mm'),
            dz_agarre_mm=p('dz_agarre_mm'), dz_dejar_mm=p('dz_dejar_mm'))
        self._q_inicio = np.array(p('pose_inicio'), float)
        self._log('desglose_tiempos.csv',
                  ['seq', 'client_id', 'frase', 'accion', 'color', 'zona', 'prioridad', 'fuente',
                   'resultado', 'captura_ms', 'transcripcion_ms', 'decision_ms', 'espera_cola_ms',
                   'percepcion_ms', 'ik_ms', 'plan_ms', 'voz_a_movimiento_ms', 'ejecucion_s',
                   'error_fk_mm', 'error_fk_fuente'], 'w')
        for aviso in self._plan.diagnostico_alcance():
            self.get_logger().warn(f'ALCANCE: {aviso}  (revisa mesa_* y q_agarre_ref)')
        self.get_logger().info(
            f"Gran Reto listo: accion=/arm/pick_place | objetos={list(self._mesa.objetos)} | "
            f"zonas={list(self._mesa.zonas)} | q_agarre_ref={list(p('q_agarre_ref'))}")

    # ---- portero (mismo goal_callback del RB-2: rechaza ANTES de encolar) ----
    def _goal_cb_pick(self, req):
        with self._lock:
            full = len(self._sched) >= self._max_queue
        if not req.client_id:
            return self._reject(req, 'NO_CLIENT', 'client_id vacio')
        if full:
            return self._reject(req, 'QUEUE_FULL', f'cola llena ({self._max_queue})')
        ok, code, msg, _ = validar_orden(req, self._mesa)
        # el motivo lleva la frase para que el cliente pueda emparejar su rechazo
        return GoalResponse.ACCEPT if ok else self._reject(req, code, f"'{req.frase}' -> {msg}")

    def _accepted_pick_cb(self, gh):            # SOLO encola, igual que _accepted_cb
        r = gh.request
        with self._lock:
            self._seq += 1
            e = Entry(self._seq, r.client_id, min(int(r.priority), 2), time.monotonic(), [],
                      t_wall=time.time(), gh=gh, kind='pick', orden=r)
            self._by_uuid[bytes(gh.goal_id.uuid)] = e
            self._sched.push(e)
            self._n_acc += 1
        self.get_logger().info(f"encolado #{e.seq} [{e.client_id}] prio={e.priority} "
                               f"PICK '{r.frase}' ({r.fuente})")

    # ---- worker: ejecuta la orden (percepcion -> IK -> trayectoria -> gripper) ----
    def _run_pick(self, e):
        o, t = e.orden, {}
        t['espera_cola_ms'] = (e.t_start - e.t_enq) * 1000.0
        self._fb(e, 'PERCEIVING', 0.0)
        if o.accion == 'ir_inicio':
            t.update(percepcion_ms=0.0, ik_ms=0.0, plan_ms=0.0)
            pasos, destino, color = [('inicio', self._q_inicio.copy(), None)], None, ''
        else:
            _, _, _, color = validar_orden(o, self._mesa)
            t0 = time.perf_counter()
            pos = self._percibir(color, o.objeto)                      # TODO(RB-2): camara
            t['percepcion_ms'] = (time.perf_counter() - t0) * 1000.0
            if pos is None:
                self._fila_desglose(e, t, 'fallo_percepcion', 0.0, -1.0, '')
                return 'aborted', f"la camara no localiza el objeto '{color}'"
            self._fb(e, 'PLANNING', 0.0)
            plan = self._plan.planear(color, o.zona, self._cur_q, pos)   # IK + admision interna
            t['ik_ms'], t['plan_ms'] = plan.ik_ms, plan.plan_ms
            if not plan.ok:
                self._fila_desglose(e, t, 'fallo_planificacion', 0.0, -1.0, '')
                return 'aborted', plan.motivo
            pasos, destino = plan.pasos, plan.destino_mm
        t_ini = time.monotonic()
        err, fuente = -1.0, ''
        for i, (nombre, q, gripper) in enumerate(pasos):
            res = self._segmento(e, q, 'EXECUTING', i / len(pasos))
            if res:
                self._fila_desglose(e, t, 'cancelada', time.monotonic() - t_ini, -1.0, '')
                return 'canceled', 'cancelado durante la ejecucion'
            if nombre == 'deposito' and destino is not None:
                # error entre la posicion SOLICITADA y la ALCANZADA, con la FK del RB-2
                q_real = self._leer_q_real()                            # lectura real del brazo
                fuente = 'real' if q_real is not None else 'comandado'
                err = float(np.linalg.norm(
                    fk(q_real if q_real is not None else q)[:3, 3] - np.array(destino)))
            if gripper:
                self._fb(e, 'GRIPPER', (i + 1) / len(pasos))
                self._gripper(gripper)                                  # pinza real si esta habilitada
        with self._lock:                  # tras un pick, la referencia de "paso" es la pose real
            if not any(x.kind == 'move' for x in self._sched.items):
                self._ref_q = self._cur_q.copy()
        e.extra['error_fk_mm'] = err
        self._fila_desglose(e, t, 'ok', time.monotonic() - t_ini, err, fuente)
        return 'succeeded', 'ok' if fuente != 'comandado' else 'ok (error FK sobre q comandado)'

    def _run_pick_seguro(self, e):
        try:
            return self._run_pick(e)
        except Exception as ex:            # el cliente siempre recibe un resultado
            self.get_logger().error(f'#{e.seq} fallo inesperado en pick: {ex!r}')
            return 'aborted', f'error interno: {ex!r}'

    def _segmento(self, e, q1, estado, progreso0):
        """Lleva el brazo hasta q1. True si cancelado.
        Real: UN destino + espera is_moving. Simulacion: interpola y publica a 20 Hz."""
        if self._mc is not None:
            return self._segmento_real(e, np.array(q1, float), estado, progreso0)
        q0, q1 = self._cur_q.copy(), np.array(q1, float)
        n = max(int(np.abs(q1 - q0).max() / self._vmax * RATE), 2)
        for i in range(1, n + 1):
            if e.gh.is_cancel_requested:
                return True
            self._publish_joint_state(q0 + (q1 - q0) * (0.5 - 0.5 * np.cos(np.pi * i / n)))
            e.extra.setdefault('t_primer_mov', time.time())       # "el brazo inicia el movimiento"
            self._fb(e, estado, progreso0)
            time.sleep(1.0 / RATE)
        return False

    def _fb(self, e, estado, progreso):
        e.gh.publish_feedback(PickPlace.Feedback(queue_position=0, state=estado, progress=float(progreso)))

    # ---- ganchos hacia lo construido en los retos previos ----
    def _percibir(self, color, objeto):
        """Camara: devolver (x, y, z) mm del objeto en el marco de la base, o None si no
        lo ve. Por defecto: posicion conocida de la mesa (catalogo) -> CAMARA NO CONECTADA."""
        _, x, y, z = self._mesa.objetos[color]
        return (x, y, z)

    def _gripper(self, accion):
        """accion: 'abrir' | 'cerrar'. Mueve la pinza real solo con driver:=real y
        habilitar_gripper:=true; si no, solo registra."""
        self.get_logger().info(f'[GRIPPER] {accion}')
        if self._mc is not None and self.get_parameter('habilitar_gripper').value:
            try:
                self._mc.set_gripper_value(100 if accion == 'abrir' else 0, 50)
            except Exception as ex:
                self.get_logger().error(f'fallo del gripper: {ex!r}')
            time.sleep(1.0)
        else:
            time.sleep(0.5)

    def _leer_q_real(self):
        """Angulos REALES del brazo (rad) desde el driver; None si no hay lectura."""
        raw = self._leer_raw_deg()
        return None if raw is None else [math.radians(v) for v in raw[:6]]

    def _fila_desglose(self, e, t, resultado, ejecucion_s, err, fuente):
        o = e.orden
        v2m = -1.0
        if o.t_fin_habla > 0 and 't_primer_mov' in e.extra:
            v2m = (e.extra['t_primer_mov'] - o.t_fin_habla) * 1000.0
        e.extra['voz_a_movimiento_ms'] = v2m
        self._log('desglose_tiempos.csv', [
            e.seq, e.client_id, o.frase, o.accion, o.color, o.zona, e.priority, o.fuente,
            resultado, f'{o.captura_ms:.1f}', f'{o.transcripcion_ms:.1f}', f'{o.decision_ms:.1f}',
            f"{t.get('espera_cola_ms', 0):.1f}", f"{t.get('percepcion_ms', 0):.1f}",
            f"{t.get('ik_ms', 0):.1f}", f"{t.get('plan_ms', 0):.1f}", f'{v2m:.1f}',
            f'{ejecucion_s:.2f}', f'{err:.2f}', fuente])

    def _await_result_pick(self, gh):
        """execute_callback de PickPlace: espera al worker y cierra el goal."""
        e = self._by_uuid.pop(bytes(gh.goal_id.uuid), None)
        res = PickPlace.Result()
        if e is None:
            gh.abort()
            res.message = 'error interno'
            return res
        while not e.done.wait(0.1) and rclpy.ok():
            pass
        if gh.is_cancel_requested:
            gh.canceled()
        elif e.outcome == 'succeeded':
            gh.succeed()
        else:
            gh.abort()
        res.success = e.outcome == 'succeeded' and not gh.is_cancel_requested
        res.message, res.final_q = e.message, e.final_q
        res.error_fk_mm = float(e.extra.get('error_fk_mm', -1.0))
        res.voz_a_movimiento_ms = float(e.extra.get('voz_a_movimiento_ms', -1.0))
        return res

    # ---- /arm/queue_state (5 Hz) ----
    def _publish_queue_state(self):
        now = time.monotonic()
        with self._lock:
            q = sorted((e for e in self._sched.items if not e.gh.is_cancel_requested), key=lambda e: e.seq)
            act, counts = self._active, (self._n_acc, self._n_rej, self._n_done)
        m = QueueState(policy=self._sched.policy, queue_length=len(q),
                       executing_client=act.client_id if act else '',
                       executing_seq=act.seq if act else 0,
                       queued_seq=[e.seq for e in q], queued_clients=[e.client_id for e in q],
                       queued_priorities=[e.priority for e in q],
                       queued_wait_s=[now - e.t_enq for e in q],
                       total_accepted=counts[0], total_rejected=counts[1], total_done=counts[2])
        m.stamp = self.get_clock().now().to_msg()
        self._qs_pub.publish(m)

    def _log(self, name, row, mode='a'):
        with self._log_lock, open(os.path.join(self._dir, name), mode, newline='') as f:
            csv.writer(f).writerow(row)


def main():
    rclpy.init()
    node = ArmBroker()
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(node)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
