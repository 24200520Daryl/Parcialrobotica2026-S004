"""Percepcion USB para JetCobot: deteccion de colores con OpenCV.

La deteccion devuelve el centro del objeto en pixeles.
Las coordenadas 3D solo se habilitaran despues de calibrar la camara.
No utilizar posiciones del catalogo como sustituto de una deteccion.
"""
import threading
import time

import cv2
import numpy as np


class VisionMesa:
    COLORES_HSV = {
        # Rojo: dos intervalos por el salto del tono HSV.
        "rojo": [
            ((0, 90, 50), (10, 255, 255)),
            ((170, 90, 50), (179, 255, 255)),
        ],
        "verde": [
            ((35, 60, 40), (90, 255, 255)),
        ],
        "azul": [
            ((90, 70, 40), (135, 255, 255)),
        ],
        "amarillo": [
            ((18, 80, 70), (38, 255, 255)),
        ],
    }

    def __init__(self, dispositivo=0, ancho=640, alto=480,
                 area_minima=500, timeout_s=2.0):
        self.dispositivo = int(dispositivo)
        self.ancho = int(ancho)
        self.alto = int(alto)
        self.area_minima = int(area_minima)
        self.timeout_s = float(timeout_s)
        self._lock = threading.Lock()
        self._cap = None

    def abrir(self):
        with self._lock:
            if self._cap is not None and self._cap.isOpened():
                return True
            cap = cv2.VideoCapture(self.dispositivo, cv2.CAP_V4L2)
            if not cap.isOpened():
                cap.release()
                return False
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.ancho)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.alto)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            self._cap = cap
            return True

    def cerrar(self):
        with self._lock:
            if self._cap is not None:
                self._cap.release()
                self._cap = None

    def detectar(self, color):
        """Devuelve (u, v, area) o None. u,v son pixeles, NO milimetros."""
        color = str(color).strip().lower()
        intervalos = self.COLORES_HSV.get(color)
        if not intervalos:
            return None

        if not self.abrir():
            return None

        limite = time.monotonic() + self.timeout_s
        mejor = None

        while time.monotonic() < limite:
            with self._lock:
                if self._cap is None or not self._cap.isOpened():
                    return None
                ok, frame = self._cap.read()

            if not ok or frame is None:
                continue

            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = np.zeros(hsv.shape[:2], dtype=np.uint8)

            for inferior, superior in intervalos:
                mask |= cv2.inRange(
                    hsv, np.array(inferior, dtype=np.uint8),
                    np.array(superior, dtype=np.uint8))

            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

            contornos, _ = cv2.findContours(
                mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            candidatos = []
            for c in contornos:
                area = cv2.contourArea(c)
                if area < self.area_minima:
                    continue
                m = cv2.moments(c)
                if m["m00"] <= 0:
                    continue
                u = m["m10"] / m["m00"]
                v = m["m01"] / m["m00"]
                candidatos.append((float(u), float(v), float(area)))

            # No escoger arbitrariamente si hay varios objetos del mismo color.
            if len(candidatos) == 1:
                mejor = candidatos[0]
            elif len(candidatos) > 1:
                mejor = None

            if mejor is not None:
                return mejor

        return None
