"""Servidor LAYA FALSO (solo para ensayar en casa; NO es el servidor del examen).

Imita POST /v1/systemone con el mismo formato de respuesta, y permite simular
un servidor lento o caído para probar el timeout y el modo degradado:

    ros2 run gran_reto_jetcobot laya_falso --puerto 8000 --retardo 0.05
    ros2 run gran_reto_jetcobot laya_falso --puerto 8000 --retardo 5     # provoca timeout

Responde con el clasificador de palabras clave, así que sirve para ver el flujo
completo, pero no mide la exactitud real de LAYA.
"""
from __future__ import annotations

import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .clasificador_palabras import NINGUNO, ClasificadorPalabras


def _crear_handler(retardo_s: float):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silencio
            pass

        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')

        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            req = json.loads(self.rfile.read(n) or b"{}")
            t0 = time.perf_counter()
            qs = req.get("questions", {})
            frase = (req.get("state") or {}).get("orden", "")
            cl = ClasificadorPalabras(
                [c for c in qs.get("color", {}).get("criteria", {})],
                [o for o in qs.get("objeto", {}).get("criteria", {})],
                [z for z in qs.get("zona", {}).get("criteria", {})])
            d = cl.clasificar(frase)
            time.sleep(retardo_s)
            ans = {
                "accion": {"choice": d.accion, "answer_confidence": 0.9},
                "objeto": {"choice": d.objeto, "answer_confidence": 0.9},
                "color": {"choice": d.color, "answer_confidence": 0.9},
                "zona": {"choice": d.zona or NINGUNO, "answer_confidence": 0.9},
                "urgencia": {"score": {1: 2.0, 2: 1.0, 3: 0.0}[d.prioridad]},
                "prohibida": {"noul": 0.0 if d.permitido else 0.97},
            }
            cuerpo = json.dumps({
                "answers": ans, "usage": {"input_tokens": 0, "output_tokens": 0},
                "latency_ms": (time.perf_counter() - t0) * 1000.0}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
    return Handler


def servir(puerto: int, retardo_s: float) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("0.0.0.0", puerto), _crear_handler(retardo_s))
    return srv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--puerto", type=int, default=8000)
    ap.add_argument("--retardo", type=float, default=0.03, help="segundos de 'cómputo'")
    a = ap.parse_args()
    print(f"LAYA FALSO en :{a.puerto}  retardo={a.retardo}s  (Ctrl+C para salir)")
    servir(a.puerto, a.retardo).serve_forever()


if __name__ == "__main__":
    main()
