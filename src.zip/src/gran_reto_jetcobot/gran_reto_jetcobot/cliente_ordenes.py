#!/usr/bin/env python3
"""Cliente de órdenes ESCRITAS (Pregunta 2). Cada integrante corre uno en su
máquina con su `origen`; los cuatro envían órdenes en paralelo a la misma cola."""
import threading

import rclpy
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from .puente_ordenes import PuenteOrdenes


class ClienteOrdenes(Node):
    def __init__(self):
        super().__init__("cliente_ordenes")
        self.declare_parameter("origen", "integrante_1")
        self.puente = PuenteOrdenes(self, self.get_parameter("origen").value)
        threading.Thread(target=self._bucle, daemon=True).start()

    def _bucle(self):
        if not self.puente.esperar_servicios():
            return
        print("Escribe una orden (Ctrl+D para salir):")
        while rclpy.ok():
            try:
                frase = input("orden> ").strip()
            except EOFError:
                break
            if frase:
                print("  " + self.puente.resumen(self.puente.procesar(frase)))
        rclpy.try_shutdown()


def main(args=None):
    rclpy.init(args=args)
    nodo = ClienteOrdenes()
    ej = MultiThreadedExecutor(num_threads=4)
    ej.add_node(nodo)
    try:
        ej.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
