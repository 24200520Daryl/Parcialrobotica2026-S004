#!/usr/bin/env python3
"""Nodo `transcriptor_voz`.

audio (micrófono o archivo) --Google AI Studio--> texto --/interpretar_orden--> decisión
                                   |
                                   +-- si hay timeout / sin internet / sin clave:
                                       MODO TECLADO (se informa y el sistema sigue)

Este nodo NO habla con LAYA y NO publica al brazo: solo usa servicios.
"""
import json
import os
import shutil
import threading
import time
from datetime import datetime

import rclpy
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

from . import gemini_stt
from .captura_audio import SinVoz, grabar_microfono
from .puente_ordenes import PuenteOrdenes


class TranscriptorVoz(Node):
    def __init__(self):
        super().__init__("transcriptor_voz")
        self.declare_parameter("fuente", "microfono")        # microfono | archivo | teclado
        self.declare_parameter("archivos_audio", [""])        # para fuente=archivo
        self.declare_parameter("origen", "integrante_1")
        self.declare_parameter("modelo_gemini", "gemini-flash-latest")
        self.declare_parameter("base_url_gemini", gemini_stt.BASE_URL)
        self.declare_parameter("timeout_stt_s", 6.0)          # <<< TIMEOUT PROPIO
        self.declare_parameter("enfriamiento_nube_s", 30.0)   # tras fallar, no reintenta antes
        self.declare_parameter("dir_registro", os.path.expanduser("~/gran_reto_registros"))
        self.declare_parameter("silencio_fin_s", 0.8)
        self.declare_parameter("max_grabacion_s", 10.0)
        self.declare_parameter("umbral_rms", 500.0)
        self.declare_parameter("dispositivo_audio", -1)       # -1 = predeterminado

        p = lambda n: self.get_parameter(n).value
        self.origen = p("origen")
        self.dir = p("dir_registro")
        os.makedirs(self.dir, exist_ok=True)
        self._lock = threading.Lock()
        self._nube_bloqueada_hasta = 0.0
        self._ultimo_texto = ""

        self.pub_estado = self.create_publisher(String, "/transcriptor_voz/estado", 10)
        self.puente = PuenteOrdenes(self, self.origen)
        threading.Thread(target=self._bucle, daemon=True).start()

    # ----------------------------------------------------------- utilidades
    def _estado(self, texto: str, error: bool = False):
        (self.get_logger().error if error else self.get_logger().info)(texto)
        m = String()
        m.data = texto
        self.pub_estado.publish(m)

    def _registrar(self, **campos):
        campos["ts"] = datetime.now().isoformat(timespec="milliseconds")
        campos["origen"] = self.origen
        with self._lock, open(os.path.join(self.dir, "transcripciones.jsonl"), "a",
                              encoding="utf-8") as f:
            f.write(json.dumps(campos, ensure_ascii=False) + "\n")

    # ------------------------------------------------------ nube o teclado
    def _transcribir_o_teclado(self, ruta_audio):
        """Devuelve (texto, fuente_texto, stt_ms, motivo_fallback)."""
        if not ruta_audio:                       # entrada de texto pedida por el operador
            return self._leer_teclado(), "teclado", 0.0, "solicitado por el operador"
        motivo = None
        if time.monotonic() < self._nube_bloqueada_hasta:
            motivo = "nube en enfriamiento tras un fallo reciente"
        else:
            clave = gemini_stt.leer_api_key()          # <<< SOLO desde os.environ
            if clave is None:
                motivo = "falta GEMINI_API_KEY / GOOGLE_API_KEY en el entorno"
            else:
                t0 = time.perf_counter()
                try:
                    texto = gemini_stt.transcribir(
                        ruta_audio, clave, self.get_parameter("modelo_gemini").value,
                        float(self.get_parameter("timeout_stt_s").value),
                        base_url=self.get_parameter("base_url_gemini").value)
                    return texto, "gemini", (time.perf_counter() - t0) * 1000.0, ""
                except gemini_stt.ErrorTranscripcion as e:
                    motivo = str(e)
                    self._nube_bloqueada_hasta = time.monotonic() + float(
                        self.get_parameter("enfriamiento_nube_s").value)

        self._estado(f"TRANSCRIPCIÓN EN LA NUBE NO DISPONIBLE ({motivo}). "
                     f"PASANDO A MODO TEXTO POR TECLADO.", error=True)
        return self._leer_teclado(), "teclado", 0.0, motivo

    @staticmethod
    def _leer_teclado() -> str:
        return input("[MODO TECLADO] Escribe la orden: ").strip()

    # --------------------------------------------------------------- flujo
    def _procesar(self, ruta_audio, t_fin_habla, captura_ms):
        texto, fuente_texto, stt_ms, motivo = self._transcribir_o_teclado(ruta_audio)
        self._ultimo_texto = texto.lower()
        if not texto or self._ultimo_texto in ("q", "salir"):
            return
        if fuente_texto == "teclado":          # ya no es voz: el reloj parte ahora
            t_fin_habla, captura_ms = time.time(), 0.0
        print(f'  transcripción [{fuente_texto}] ({stt_ms:.0f} ms): "{texto}"')
        r = self.puente.procesar(texto, t_fin_habla, captura_ms, stt_ms)
        print("  " + self.puente.resumen(r))
        d = r.get("decision")
        self._registrar(audio=ruta_audio, texto=texto, fuente_texto=fuente_texto,
                        stt_ms=round(stt_ms, 1), captura_ms=round(captura_ms, 1),
                        motivo_fallback=motivo,
                        decision=None if d is None else {
                            "accion": d.accion, "objeto": d.objeto, "color": d.color,
                            "zona": d.zona, "prioridad": d.prioridad,
                            "permitido": d.permitido, "degradado": d.degradado},
                        broker=None if "broker" not in r else {
                            "aceptada": r["broker"].aceptada, "causa": r["broker"].causa,
                            "id_orden": r["broker"].id_orden})

    def _guardar_copia(self, ruta_origen) -> str:
        """Copia el audio al registro para poder revisar qué entendió el sistema."""
        sello = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        destino = os.path.join(self.dir, f"audio_{sello}{os.path.splitext(ruta_origen)[1]}")
        shutil.copy2(ruta_origen, destino)
        return destino

    def _bucle(self):
        try:
            self._bucle_interno()
        except EOFError:
            pass
        rclpy.try_shutdown()

    def _bucle_interno(self):
        if not self.puente.esperar_servicios():
            return
        fuente = self.get_parameter("fuente").value
        if fuente == "archivo":
            for ruta in [a for a in self.get_parameter("archivos_audio").value if a]:
                print(f"\nArchivo: {ruta}")
                self._procesar(self._guardar_copia(ruta), time.time(), 0.0)
            print("\nArchivos procesados.")
            return
        print("\nModo", fuente, "- Enter = hablar, 't' = escribir, 'q' = salir")
        while rclpy.ok():
            if fuente == "teclado":
                self._procesar("", 0.0, 0.0)      # (escribe 'q' para salir)
                if self._ultimo_texto in ("q", "salir"):
                    break
                continue
            cmd = input("[Enter]=hablar  t=teclado  q=salir > ").strip().lower()
            if cmd == "q":
                break
            if cmd == "t":
                self._procesar("", 0.0, 0.0)
                continue
            ruta = os.path.join(self.dir, "audio_"
                                f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.wav")
            try:
                dev = int(self.get_parameter("dispositivo_audio").value)
                print("  Escuchando... (habla ahora)")
                cap = grabar_microfono(
                    ruta, max_s=float(self.get_parameter("max_grabacion_s").value),
                    silencio_fin_s=float(self.get_parameter("silencio_fin_s").value),
                    umbral_rms=float(self.get_parameter("umbral_rms").value),
                    dispositivo=None if dev < 0 else dev)
            except (SinVoz, RuntimeError, OSError) as e:
                self._estado(f"Captura fallida: {e}", error=True)
                continue
            self._procesar(cap.ruta, cap.t_fin_habla, cap.captura_ms)


def main(args=None):
    rclpy.init(args=args)
    nodo = TranscriptorVoz()
    ej = MultiThreadedExecutor(num_threads=4)
    ej.add_node(nodo)
    try:
        ej.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
