#!/usr/bin/env python3
"""Mide la Pregunta 1: latencia (mediana / p95) y exactitud sobre las 50 frases.

Llama al SERVICIO /interpretar_orden (no habla con LAYA directamente: la regla
del examen es que solo interprete_ordenes lo hace). El clasificador por palabras
clave se evalúa localmente sobre las mismas frases.

CSV de entrada (cabecera obligatoria):
    frase,accion,objeto,color,zona,permitido      (permitido = 1/0, o true/false)

Uso:
    ros2 run gran_reto_jetcobot medir_latencia --frases datos/frases50.csv \
        --etiqueta calma --prediccion-mediana-ms 60
"""
import argparse
import csv
import statistics
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.utilities import remove_ros_args

from jetcobot_interfaces.srv import InterpretarOrden

from .clasificador_palabras import ClasificadorPalabras

CAMPOS = ("accion", "objeto", "color", "zona", "permitido")


def percentil(valores, q):
    """Percentil con interpolación lineal (igual que numpy.percentile)."""
    v = sorted(valores)
    if not v:
        return float("nan")
    k = (len(v) - 1) * q / 100.0
    i = int(k)
    return v[i] if i + 1 >= len(v) else v[i] + (v[i + 1] - v[i]) * (k - i)


def _bool(x):
    return str(x).strip().lower() in ("1", "true", "si", "sí", "t", "yes")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--frases", required=True)
    ap.add_argument("--etiqueta", default="calma", help="calma | carga")
    ap.add_argument("--salida", default="")
    ap.add_argument("--repeticiones", type=int, default=1)
    ap.add_argument("--colores", default="P1,P2,P3,P4")
    ap.add_argument("--objetos", default="cubo,cilindro,esfera,prisma")
    ap.add_argument("--zonas", default="A,B,C")
    ap.add_argument("--prediccion-mediana-ms", type=float, default=None,
                    help="valor que PREDIJISTE antes de medir (el examen lo califica)")
    a = ap.parse_args(remove_ros_args(sys.argv if argv is None else argv)[1:])

    rclpy.init()
    nodo = Node("medir_latencia")
    cli = nodo.create_client(InterpretarOrden, "/interpretar_orden")
    if not cli.wait_for_service(timeout_sec=15):
        print("No existe /interpretar_orden (¿ROS_DOMAIN_ID correcto?)")
        return 1
    kw = ClasificadorPalabras(a.colores.split(","), a.objetos.split(","), a.zonas.split(","))

    with open(a.frases, newline="", encoding="utf-8") as f:
        filas = list(csv.DictReader(f))
    out = []
    for rep in range(a.repeticiones):
        for fila in filas:
            gold = {c: (_bool(fila[c]) if c == "permitido" else fila[c].strip())
                    for c in CAMPOS}
            req = InterpretarOrden.Request()
            req.frase = fila["frase"]
            t0 = time.perf_counter()
            fut = cli.call_async(req)
            rclpy.spin_until_future_complete(nodo, fut, timeout_sec=30)
            ciclo_ms = (time.perf_counter() - t0) * 1000.0
            r = fut.result()
            if r is None:
                print("sin respuesta para:", req.frase)
                continue
            laya = {"accion": r.accion, "objeto": r.objeto, "color": r.color,
                    "zona": r.zona, "permitido": r.permitido}
            d = kw.clasificar(req.frase)
            palabras = {"accion": d.accion, "objeto": d.objeto, "color": d.color,
                        "zona": d.zona, "permitido": d.permitido}
            out.append({
                "rep": rep, "frase": req.frase, **{f"esp_{c}": gold[c] for c in CAMPOS},
                **{f"laya_{c}": laya[c] for c in CAMPOS},
                "laya_prioridad": r.prioridad, "laya_degradado": int(r.degradado),
                "laya_fuente": r.fuente, "total_ms": round(r.latencia_total_ms, 2),
                "red_ms": round(r.latencia_red_ms, 2),
                "computo_ms": round(r.latencia_computo_ms, 2),
                "ciclo_servicio_ms": round(ciclo_ms, 2),
                **{f"kw_{c}": palabras[c] for c in CAMPOS},
                "kw_prioridad": d.prioridad,
                "laya_ok": int(laya == gold and not r.degradado),
                "kw_ok": int(palabras == gold)})

    salida = a.salida or f"resultados_{a.etiqueta}.csv"
    with open(salida, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)

    n = len(out)
    print(f"\n=== Latencia ({a.etiqueta}) — n={n} — ms ===")
    print("| métrica | mediana | p95 |\n|---|---|---|")
    for nombre, col in (("total (cliente HTTP)", "total_ms"), ("red (RTT)", "red_ms"),
                        ("cómputo (servidor)", "computo_ms")):
        v = [x[col] for x in out if x[col] >= 0 and not x["laya_degradado"]]
        if v:
            print(f"| {nombre} | {statistics.median(v):.1f} | {percentil(v, 95):.1f} |")
        else:
            print(f"| {nombre} | n/d | n/d |")
    deg = sum(x["laya_degradado"] for x in out)
    print(f"\nRespuestas degradadas (timeout/fallo): {deg}/{n}")
    print("\n=== Exactitud (decisión completa = acción+objeto+color+zona+permitido) ===")
    print("| método | aciertos | exactitud |\n|---|---|---|")
    for nom, col in (("LAYA", "laya_ok"), ("Palabras clave", "kw_ok")):
        s = sum(x[col] for x in out)
        print(f"| {nom} | {s}/{n} | {100.0 * s / n:.1f}% |")
    if a.prediccion_mediana_ms is not None:
        v = [x["total_ms"] for x in out if not x["laya_degradado"]]
        med = statistics.median(v) if v else float("nan")
        print(f"\nPredicho (mediana total): {a.prediccion_mediana_ms:.1f} ms | "
              f"medido: {med:.1f} ms | diferencia: {med - a.prediccion_mediana_ms:+.1f} ms")
    print(f"\nCSV: {salida}")
    nodo.destroy_node()
    rclpy.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
