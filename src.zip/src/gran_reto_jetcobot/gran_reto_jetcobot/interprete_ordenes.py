#!/usr/bin/env python3
"""Nodo `interprete_ordenes` — ÚNICO punto de contacto con el servidor LAYA.

Servicio: /interpretar_orden  (jetcobot_interfaces/srv/InterpretarOrden)
  frase (español)  ->  accion, objeto, color, zona, prioridad, permitido + trazabilidad

Flujo por petición:
  1. Consulta LAYA por HTTP con un TIEMPO LÍMITE (parámetro `timeout_s`).
  2. Si LAYA falla o excede el límite -> clasificador por palabras clave y
     `degradado = True`. El servicio SIEMPRE responde.
  3. Registra latencia total / red / cómputo en CSV y en el tópico de métricas.
"""
import csv
import json
import os
import threading
import time
from datetime import datetime

import rclpy
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

from jetcobot_interfaces.srv import InterpretarOrden

from .clasificador_palabras import ClasificadorPalabras
from .laya_cliente import LayaCliente, LayaError, LayaTimeout

CABECERA_CSV = ["ts", "frase", "fuente", "degradado", "accion", "objeto", "color",
                "zona", "prioridad", "permitido", "total_ms", "red_ms",
                "computo_ms", "detalle"]


class InterpreteOrdenes(Node):
    def __init__(self):
        super().__init__("interprete_ordenes")

        # ------------------------------------------------------------ parámetros
        self.declare_parameter("laya_host", "127.0.0.1")      # IP que entrega el docente
        self.declare_parameter("laya_puerto", 8000)           # puerto que entrega el docente
        self.declare_parameter("laya_endpoint", "/v1/systemone")
        self.declare_parameter("laya_modelo", "multilingual")  # checkpoint (español)
        self.declare_parameter("laya_preset", "")              # solo si el docente lo pide
        self.declare_parameter("laya_https", False)
        self.declare_parameter("timeout_s", 2.0)               # <<< TIEMPO LÍMITE
        self.declare_parameter("enfriamiento_laya_s", 0.0)     # 0 = sin cortacircuito
        self.declare_parameter("umbral_prohibida", 0.5)
        self.declare_parameter("colores", ["P1", "P2", "P3", "P4"])
        self.declare_parameter("objetos", ["cubo", "cilindro", "esfera", "prisma"])
        self.declare_parameter("zonas", ["A", "B", "C"])
        self.declare_parameter("csv_log", os.path.expanduser(
            "~/gran_reto_logs/interprete_latencias.csv"))

        p = lambda n: self.get_parameter(n).value
        colores, objetos, zonas = list(p("colores")), list(p("objetos")), list(p("zonas"))

        # La clave (si el servidor del lab la exigiera) también va por entorno.
        self.laya = LayaCliente(
            host=p("laya_host"), puerto=int(p("laya_puerto")),
            endpoint=p("laya_endpoint"), modelo=p("laya_modelo"),
            preset=p("laya_preset"), api_key=os.environ.get("LAYA_API_KEY"),
            usar_https=bool(p("laya_https")), colores=colores, objetos=objetos,
            zonas=zonas, umbral_prohibida=float(p("umbral_prohibida")))
        self.clasificador = ClasificadorPalabras(colores, objetos, zonas)

        self._lock = threading.Lock()
        self._fallos_seguidos = 0
        self._laya_bloqueada_hasta = 0.0

        ruta = p("csv_log")
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        self._csv_ruta = ruta
        if not os.path.exists(ruta):
            with open(ruta, "w", newline="") as f:
                csv.writer(f).writerow(CABECERA_CSV)

        # Grupo reentrante + MultiThreadedExecutor: varias frases en paralelo
        # (los 4 integrantes) sin que una espera de red bloquee a las demás.
        self._grupo = ReentrantCallbackGroup()
        self.create_service(InterpretarOrden, "/interpretar_orden", self._callback,
                            callback_group=self._grupo)
        self._pub_metricas = self.create_publisher(
            String, "/interprete_ordenes/metricas", 50)

        self.get_logger().info(
            f"Listo. LAYA={self.laya.url} modelo='{p('laya_modelo')}' "
            f"timeout_s={p('timeout_s')}")

    # ---------------------------------------------------------------- servicio
    def _callback(self, req, res):
        t_ini = time.perf_counter()
        frase = req.frase.strip()
        timeout_s = float(self.get_parameter("timeout_s").value)  # editable en vivo

        degradado, detalle = False, ""
        comp_ms = red_ms = -1.0

        if not frase:
            d = self.clasificador.clasificar("")
            d.permitido, d.causa = False, "frase vacía"
            degradado, detalle = True, "frase_vacia"
        else:
            try:
                if time.monotonic() < self._laya_bloqueada_hasta:
                    raise LayaError("LAYA en enfriamiento (cortacircuito)")
                r = self.laya.consultar(frase, timeout_s)
                d = r.decision
                comp_ms = -1.0 if r.computo_ms is None else r.computo_ms
                red_ms = -1.0 if r.red_ms is None else r.red_ms
                self._fallos_seguidos = 0
            except (LayaTimeout, LayaError) as e:
                degradado, detalle = True, str(e)
                d = self.clasificador.clasificar(frase)
                self._registrar_fallo()
                self.get_logger().warn(
                    f"MODO DEGRADADO (palabras clave): {detalle} | frase='{frase}'")

        total_ms = (time.perf_counter() - t_ini) * 1000.0

        res.accion, res.objeto, res.color, res.zona = d.accion, d.objeto, d.color, d.zona
        res.prioridad, res.permitido, res.causa = int(d.prioridad), bool(d.permitido), d.causa
        res.confianza = float(d.confianza)
        res.degradado = degradado
        res.fuente = "palabras_clave" if degradado else "laya"
        res.detalle = detalle
        res.latencia_total_ms, res.latencia_red_ms = total_ms, red_ms
        res.latencia_computo_ms = comp_ms

        self._registrar(frase, res)
        return res

    # ------------------------------------------------------------------ apoyo
    def _registrar_fallo(self):
        espera = float(self.get_parameter("enfriamiento_laya_s").value)
        if espera <= 0:
            return
        self._fallos_seguidos += 1
        if self._fallos_seguidos >= 3:
            self._laya_bloqueada_hasta = time.monotonic() + espera

    def _registrar(self, frase, res):
        fila = [datetime.now().isoformat(timespec="milliseconds"), frase, res.fuente,
                int(res.degradado), res.accion, res.objeto, res.color, res.zona,
                res.prioridad, int(res.permitido), f"{res.latencia_total_ms:.2f}",
                f"{res.latencia_red_ms:.2f}", f"{res.latencia_computo_ms:.2f}",
                res.detalle]
        with self._lock:
            with open(self._csv_ruta, "a", newline="") as f:
                csv.writer(f).writerow(fila)
        self.get_logger().info(
            f"[{res.fuente}] '{frase}' -> {res.accion}/{res.objeto}/{res.color}/"
            f"{res.zona} prio={res.prioridad} permitido={res.permitido} "
            f"total={res.latencia_total_ms:.1f}ms red={res.latencia_red_ms:.1f}ms "
            f"computo={res.latencia_computo_ms:.1f}ms")
        msg = String()
        msg.data = json.dumps(dict(zip(CABECERA_CSV, fila)), ensure_ascii=False)
        self._pub_metricas.publish(msg)   # para grabarlo en el ros2 bag


def main(args=None):
    rclpy.init(args=args)
    nodo = InterpreteOrdenes()
    ejecutor = MultiThreadedExecutor(num_threads=8)
    ejecutor.add_node(nodo)
    try:
        ejecutor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
