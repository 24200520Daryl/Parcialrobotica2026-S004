"""Pruebas del núcleo sin ROS:  python3 -m unittest discover -s test -v"""
import os, sys, threading, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gran_reto_jetcobot.clasificador_palabras import ClasificadorPalabras
from gran_reto_jetcobot.laya_cliente import LayaCliente, LayaError, LayaTimeout
from gran_reto_jetcobot import laya_falso

COL = ["rojo", "verde", "azul", "amarillo"]
OBJ = ["cubo", "cilindro", "esfera", "prisma"]
ZON = ["A", "B", "C"]


class TestClasificador(unittest.TestCase):
    def setUp(self):
        self.c = ClasificadorPalabras(COL, OBJ, ZON)

    def test_pick_basico(self):
        d = self.c.clasificar("Recoge el cubo rojo y ponlo en la zona B")
        self.assertEqual((d.accion, d.objeto, d.color, d.zona, d.permitido),
                         ("recoger_y_colocar", "cubo", "rojo", "B", True))

    def test_color_de_zona_no_es_del_objeto(self):
        d = self.c.clasificar("lleva el cilindro verde a la zona azul")
        self.assertEqual((d.color, d.objeto), ("verde", "cilindro"))

    def test_prohibida(self):
        d = self.c.clasificar("Tira el cubo azul al suelo")
        self.assertFalse(d.permitido)
        self.assertTrue(d.causa)

    def test_prioridad(self):
        self.assertEqual(self.c.clasificar("recoge el cubo rojo urgente").prioridad, 1)
        self.assertEqual(self.c.clasificar("recoge el cubo rojo sin prisa").prioridad, 3)
        self.assertEqual(self.c.clasificar("recoge el cubo rojo").prioridad, 2)

    def test_inicio_y_desconocida(self):
        self.assertEqual(self.c.clasificar("vuelve a la posición de inicio").accion,
                         "ir_inicio")
        self.assertEqual(self.c.clasificar("qué hora es").accion, "desconocida")

    def test_tildes(self):
        d = self.c.clasificar("Recoge el CÍLINDRO AMARILLO")
        self.assertEqual((d.objeto, d.color), ("cilindro", "amarillo"))


class TestLayaCliente(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv_ok = laya_falso.servir(18101, 0.03)
        cls.srv_lento = laya_falso.servir(18102, 3.0)
        for s in (cls.srv_ok, cls.srv_lento):
            threading.Thread(target=s.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv_ok.shutdown(); cls.srv_lento.shutdown()

    def _cli(self, puerto):
        return LayaCliente("127.0.0.1", puerto, colores=COL, objetos=OBJ, zonas=ZON)

    def test_respuesta_normal_y_separacion_red_computo(self):
        r = self._cli(18101).consultar("Recoge el cubo rojo y ponlo en la zona B", 2.0)
        self.assertEqual((r.decision.color, r.decision.zona), ("rojo", "B"))
        self.assertTrue(r.decision.permitido)
        self.assertIsNotNone(r.computo_ms)
        self.assertGreaterEqual(r.total_ms, r.computo_ms)
        self.assertAlmostEqual(r.red_ms, r.total_ms - r.computo_ms, places=6)

    def test_prohibida_llega_como_no_permitida(self):
        r = self._cli(18101).consultar("tira el cubo rojo al suelo", 2.0)
        self.assertFalse(r.decision.permitido)

    def test_timeout_no_espera_mas_de_lo_pedido(self):
        t0 = time.perf_counter()
        with self.assertRaises(LayaTimeout):
            self._cli(18102).consultar("recoge el cubo rojo", 0.5)
        self.assertLess(time.perf_counter() - t0, 1.0)

    def test_servidor_caido(self):
        with self.assertRaises(LayaError):
            self._cli(18199).consultar("recoge el cubo rojo", 1.0)


if __name__ == "__main__":
    unittest.main()
