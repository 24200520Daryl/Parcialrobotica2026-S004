"""Pruebas del STT con un 'Google falso' local:  python3 -m unittest discover -s test -v"""
import json, os, sys, tempfile, threading, time, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gran_reto_jetcobot import gemini_stt
from gran_reto_jetcobot.captura_audio import guardar_wav

CLAVE = "CLAVE-SECRETA-DE-PRUEBA-123"
visto = {}


def handler(retardo, status=200):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0)); cuerpo = json.loads(self.rfile.read(n))
            visto["clave_en_cabecera"] = self.headers.get("x-goog-api-key")
            visto["clave_en_url"] = CLAVE in self.path
            visto["mime"] = cuerpo["contents"][0]["parts"][1]["inline_data"]["mime_type"]
            time.sleep(retardo)
            out = json.dumps({"candidates": [{"content": {"parts": [
                {"text": '"Recoge el cubo rojo"\n'}]}}]}).encode()
            self.send_response(status); self.send_header("Content-Length", str(len(out)))
            self.end_headers(); self.wfile.write(out)
    return H


class TestSTT(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ok = ThreadingHTTPServer(("127.0.0.1", 18201), handler(0.05))
        cls.lento = ThreadingHTTPServer(("127.0.0.1", 18202), handler(3.0))
        cls.err = ThreadingHTTPServer(("127.0.0.1", 18203), handler(0.0, 403))
        for s in (cls.ok, cls.lento, cls.err):
            threading.Thread(target=s.serve_forever, daemon=True).start()
        cls.wav = os.path.join(tempfile.mkdtemp(), "t.wav")
        guardar_wav(cls.wav, b"\x00\x01" * 16000)

    def test_ok_y_clave_solo_en_cabecera(self):
        t = gemini_stt.transcribir(self.wav, CLAVE, "m", 2.0, "http://127.0.0.1:18201")
        self.assertEqual(t, "Recoge el cubo rojo")
        self.assertEqual(visto["clave_en_cabecera"], CLAVE)
        self.assertFalse(visto["clave_en_url"])
        self.assertEqual(visto["mime"], "audio/wav")

    def test_timeout_propio(self):
        t0 = time.perf_counter()
        with self.assertRaises(gemini_stt.ErrorTranscripcion) as cm:
            gemini_stt.transcribir(self.wav, CLAVE, "m", 0.5, "http://127.0.0.1:18202")
        self.assertLess(time.perf_counter() - t0, 1.0)
        self.assertIn("timeout", str(cm.exception))

    def test_sin_conexion(self):
        with self.assertRaises(gemini_stt.ErrorTranscripcion) as cm:
            gemini_stt.transcribir(self.wav, CLAVE, "m", 1.0, "http://127.0.0.1:18299")
        self.assertNotIn(CLAVE, str(cm.exception))

    def test_http_error(self):
        with self.assertRaises(gemini_stt.ErrorTranscripcion) as cm:
            gemini_stt.transcribir(self.wav, CLAVE, "m", 1.0, "http://127.0.0.1:18203")
        self.assertIn("403", str(cm.exception))

    def test_clave_desde_entorno(self):
        for k in gemini_stt.VARIABLES_CLAVE: os.environ.pop(k, None)
        self.assertIsNone(gemini_stt.leer_api_key())
        os.environ["GOOGLE_API_KEY"] = "abc"
        self.assertEqual(gemini_stt.leer_api_key(), "abc")
        os.environ["GEMINI_API_KEY"] = "xyz"
        self.assertEqual(gemini_stt.leer_api_key(), "xyz")   # GEMINI tiene prioridad
        for k in gemini_stt.VARIABLES_CLAVE: os.environ.pop(k, None)


if __name__ == "__main__":
    unittest.main()
