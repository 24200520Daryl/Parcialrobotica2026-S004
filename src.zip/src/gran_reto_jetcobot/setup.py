import os
from glob import glob
from setuptools import setup

package_name = "gran_reto_jetcobot"

setup(
    name=package_name,
    version="1.0.0",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        (os.path.join("share", package_name, "launch"), glob("launch/*.py")),
        (os.path.join("share", package_name, "config"), glob("config/*.yaml")),
        (os.path.join("share", package_name, "datos"), glob("datos/*.csv")),
    ],
    install_requires=["setuptools", "requests"],
    zip_safe=True,
    maintainer="Equipo",
    maintainer_email="karina.vera.arias@gmail.com",
    description="Gran Reto JetCobot",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "interprete_ordenes = gran_reto_jetcobot.interprete_ordenes:main",
            "transcriptor_voz = gran_reto_jetcobot.transcriptor_voz:main",
            "cliente_ordenes = gran_reto_jetcobot.cliente_ordenes:main",
            "medir_latencia = gran_reto_jetcobot.medir_latencia:main",
            "laya_falso = gran_reto_jetcobot.laya_falso:main",
        ],
    },
)
