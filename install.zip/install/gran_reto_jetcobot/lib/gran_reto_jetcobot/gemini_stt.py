"""Transcripción en español con Google AI Studio (Gemini) por REST. Sin ROS.

Se usa REST (`requests`) en vez de un SDK porque:
  * el timeout se controla exactamente (requisito del examen),
  * el SDK antiguo `google-generativeai` fue reemplazado por `google-genai`,
    y evitar la dependencia elimina problemas de versiones en el Jetson.

SEGURIDAD: la clave se lee SOLO de os.environ y viaja en la cabecera
`x-goog-api-key` (no en la URL, que podría quedar en logs). Nunca se imprime.
"""
from __future__ import annotations

import base64
import os
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturoTimeout
from typing import Optional

import requests

BASE_URL = "https://generativelanguage.googleapis.com"
VARIABLES_CLAVE = ("GEMINI_API_KEY", "GOOGLE_API_KEY")
MIME = {".wav": "audio/wav", ".mp3": "audio/mp3", ".ogg": "audio/ogg",
        ".flac": "audio/flac", ".m4a": "audio/aac", ".aac": "audio/aac",
        ".aiff": "audio/aiff"}
PROMPT = ("Transcribe literalmente este audio en español. Responde SOLO con el "
          "texto hablado, sin comillas, sin comentarios y sin añadir nada. "
          "Si no hay voz, responde exactamente: [sin voz]")
MAX_BYTES = 15 * 1024 * 1024          # límite práctico para audio en línea
_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix="stt")


class ErrorTranscripcion(Exception):
    """Falla de red, timeout, clave ausente/inválida o respuesta sin texto."""


def leer_api_key() -> Optional[str]:
    """Lee la clave del ENTORNO. Devuelve None si no está definida."""
    for nombre in VARIABLES_CLAVE:
        valor = os.environ.get(nombre, "").strip()
        if valor:
            return valor
    return None


def _llamar(ruta: str, api_key: str, modelo: str, timeout_s: float,
            base_url: str, prompt: str) -> str:
    ext = os.path.splitext(ruta)[1].lower()
    if ext not in MIME:
        raise ErrorTranscripcion(f"formato de audio no soportado: {ext}")
    with open(ruta, "rb") as f:
        datos = f.read()
    if len(datos) > MAX_BYTES:
        raise ErrorTranscripcion("audio demasiado grande para envío en línea")
    cuerpo = {
        "contents": [{"parts": [
            {"text": prompt},
            {"inline_data": {"mime_type": MIME[ext],
                             "data": base64.b64encode(datos).decode()}}]}],
        "generationConfig": {"temperature": 0, "maxOutputTokens": 256},
    }
    url = f"{base_url}/v1beta/models/{modelo}:generateContent"
    r = requests.post(url, json=cuerpo, timeout=(timeout_s, timeout_s),
                      headers={"x-goog-api-key": api_key,
                               "Content-Type": "application/json"})
    if r.status_code != 200:
        try:
            msg = r.json().get("error", {}).get("message", "")
        except ValueError:
            msg = r.text
        raise ErrorTranscripcion(f"HTTP {r.status_code}: {msg[:150]}")
    try:
        partes = r.json()["candidates"][0]["content"]["parts"]
        texto = " ".join(p.get("text", "") for p in partes).strip().strip('"')
    except (KeyError, IndexError, TypeError, ValueError):
        raise ErrorTranscripcion("respuesta sin texto (¿audio vacío o bloqueado?)")
    if not texto or texto.lower() == "[sin voz]":
        raise ErrorTranscripcion("no se detectó voz en el audio")
    return texto


def transcribir(ruta: str, api_key: str, modelo: str, timeout_s: float,
                base_url: str = BASE_URL, prompt: str = PROMPT) -> str:
    """Devuelve la transcripción o lanza ErrorTranscripcion. Nunca excede
    ~timeout_s: el deadline se impone desde fuera del hilo HTTP."""
    fut = _POOL.submit(_llamar, ruta, api_key, modelo, timeout_s, base_url, prompt)
    try:
        return fut.result(timeout=timeout_s)
    except FuturoTimeout:
        fut.cancel()
        raise ErrorTranscripcion(f"timeout: sin respuesta en {timeout_s:.1f} s") from None
    except ErrorTranscripcion:
        raise
    except requests.exceptions.Timeout:
        raise ErrorTranscripcion(f"timeout HTTP ({timeout_s:.1f} s)") from None
    except requests.exceptions.RequestException as e:
        # Sin internet / DNS / conexión rechazada. Solo el TIPO, nunca la URL ni la clave.
        raise ErrorTranscripcion(f"sin conexión ({type(e).__name__})") from None
