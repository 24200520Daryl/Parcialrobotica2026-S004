"""Clasificador por palabras clave: es el MODO DEGRADADO de `interprete_ordenes`.

- Sin ROS, sin red, sin dependencias: determinista y de menos de 1 ms.
- Devuelve la misma decisión tipada que LAYA (accion, objeto, color, zona,
  prioridad, permitido), de modo que el resto del sistema no distingue de dónde
  vino; solo el campo `degradado` lo delata.
- Los vocabularios (colores, objetos, zonas) se inyectan desde parámetros ROS.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Set

ACCION_RECOGER = "recoger_y_colocar"
ACCION_INICIO = "ir_inicio"
ACCION_DESCONOCIDA = "desconocida"
NINGUNO = "ninguno"

# Sinónimos conocidos; si un nombre configurado no está aquí se usa él mismo.
SINONIMOS_COLOR: Dict[str, tuple] = {
    "rojo": ("rojo", "roja", "rojos", "rojas"),
    "verde": ("verde", "verdes"),
    "azul": ("azul", "azules"),
    "amarillo": ("amarillo", "amarilla", "amarillos"),
    "naranja": ("naranja", "anaranjado"),
    "morado": ("morado", "morada", "violeta"),
    "negro": ("negro", "negra"),
    "blanco": ("blanco", "blanca"),
}
SINONIMOS_OBJETO: Dict[str, tuple] = {
    "cubo": ("cubo", "cubos", "bloque", "dado"),
    "cilindro": ("cilindro", "lata", "tubo"),
    "esfera": ("esfera", "bola", "pelota"),
    "prisma": ("prisma", "ladrillo"),
}

# Raíces (se comparan con el INICIO de cada palabra, ya sin tildes).
RAICES_PROHIBIDAS = ("tir", "lanz", "golpe", "romp", "destru", "aplast", "apag",
                     "atac", "lastim", "danar", "dane", "empuj", "arroj", "quem")
FRASES_PROHIBIDAS = ("al suelo", "al piso", "fuera de la mesa", "a la persona",
                     "contra la pared")
RAICES_RECOGER = ("recog", "recoj", "tom", "agarr", "coge", "cog", "lleva", "pon",
                  "coloc", "deposit", "mueve", "mover", "trae", "traer", "pasa",
                  "ubica", "situa")
TERMINOS_INICIO = ("inicio", "home", "reposo", "descans", "origen")
URGENTES = ("urgente", "inmediat", "rapid", "ahora", "pronto", "prioridad")
CALMADOS = ("despacio", "calma", "tranquil", "luego", "despues")
MARCADORES_ZONA = r"\b(?:zona|area|sector|bandeja|contenedor|caja)\s+(?:de\s+|la\s+)?([a-z0-9]+)"


def normalizar(texto: str) -> str:
    """minúsculas y sin tildes/diéresis ('Ñ' pasa a 'n')."""
    t = unicodedata.normalize("NFD", texto.lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


NUMEROS = {"uno": "1", "dos": "2", "tres": "3", "cuatro": "4"}
_PREF_POS = r"(?:posicion|pos|lugar|puesto|sitio)\s*(?:numero\s+|n\s+)?"


def a_posiciones(norm: str) -> str:
    """'posicion 2' / 'posicion dos' -> 'p2' (un solo token)."""
    for w, n in NUMEROS.items():
        norm = re.sub(rf"\b{_PREF_POS}{w}\b", f"p{n}", norm)
    return re.sub(rf"\b{_PREF_POS}(\d)\b", r"p\1", norm)


@dataclass
class Decision:
    accion: str = ACCION_DESCONOCIDA
    objeto: str = NINGUNO
    color: str = NINGUNO
    zona: str = NINGUNO
    prioridad: int = 2
    permitido: bool = True
    causa: str = ""
    confianza: float = 0.0


def _mapa(nombres: Iterable[str], sinonimos: Dict[str, tuple]) -> Dict[str, Set[str]]:
    salida: Dict[str, Set[str]] = {}
    for n in nombres:
        if normalizar(n) == NINGUNO:
            continue
        base = set(map(normalizar, sinonimos.get(n, ()))) | {normalizar(n)}
        salida[n] = base
    return salida


class ClasificadorPalabras:
    def __init__(self, colores: Iterable[str], objetos: Iterable[str],
                 zonas: Iterable[str]):
        self.colores = _mapa(colores, {})
        self.objetos = _mapa(objetos, SINONIMOS_OBJETO)
        self.zonas = {z: normalizar(z) for z in zonas if normalizar(z) != NINGUNO}

    @staticmethod
    def _empieza(tokens, raices) -> Optional[str]:
        for t in tokens:
            if any(t.startswith(r) for r in raices):
                return t
        return None

    def _buscar(self, tokens: Set[str], mapa: Dict[str, Set[str]]) -> str:
        for nombre, sins in mapa.items():
            if tokens & sins:
                return nombre
        return NINGUNO

    def clasificar(self, frase: str) -> Decision:
        norm = a_posiciones(normalizar(frase))
        tokens = re.findall(r"[a-z0-9]+", norm)
        d = Decision()

        # 1) ¿Permitida?  (verbos/frases peligrosas o fuera del alcance del brazo)
        t_mala = self._empieza(tokens, RAICES_PROHIBIDAS)
        if t_mala:
            d.permitido, d.causa = False, f"palabra prohibida '{t_mala}'"
        else:
            for f in FRASES_PROHIBIDAS:
                if f in norm:
                    d.permitido, d.causa = False, f"frase prohibida '{f}'"
                    break

        # 2) Zona: lo que sigue a "zona/area/caja..." NO es el color del objeto.
        m = re.search(MARCADORES_ZONA, norm)
        antes = norm
        if m:
            token = m.group(1)
            for nombre, n in self.zonas.items():
                if token == n or (len(token) >= 4 and token[:4] == n[:4]):
                    d.zona = nombre
                    break
            antes = norm[:m.start()]
        toks_objeto = set(re.findall(r"[a-z0-9]+", antes))

        # 3) Objeto y color (solo en la parte previa a la zona)
        d.color = self._buscar(toks_objeto, self.colores)
        d.objeto = self._buscar(toks_objeto, self.objetos)

        # 4) Acción
        if any(t in tokens for t in TERMINOS_INICIO) and d.color == NINGUNO \
                and d.objeto == NINGUNO:
            d.accion = ACCION_INICIO
        elif self._empieza(tokens, RAICES_RECOGER) or d.color != NINGUNO \
                or d.objeto != NINGUNO:
            d.accion = ACCION_RECOGER

        # 5) Prioridad
        if self._empieza(tokens, URGENTES) or "ya" in tokens:
            d.prioridad = 1
        elif self._empieza(tokens, CALMADOS) or "sin prisa" in norm:
            d.prioridad = 3

        d.confianza = 0.9 if d.accion != ACCION_DESCONOCIDA and (
            d.color != NINGUNO or d.objeto != NINGUNO
            or d.accion == ACCION_INICIO) else 0.4
        return d
