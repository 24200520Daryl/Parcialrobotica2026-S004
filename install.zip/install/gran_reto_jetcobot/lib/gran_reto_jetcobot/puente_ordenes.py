"""Puente compartido: frase -> /interpretar_orden -> accion /arm/pick_place del broker RB-2.

Lo usan `transcriptor_voz` y `cliente_ordenes`. Aqui NO se habla con LAYA (solo
interprete_ordenes lo hace) y NO se publica nada al brazo (solo arm_broker publica
en /joint_states). Este modulo solo usa un SERVICIO y una ACCION.

Rechazos: en ROS 2 el GoalResponse.REJECT no puede llevar texto, asi que el broker
publica el motivo en /arm/rejections ("cliente|CODIGO|motivo"). Aqui se escucha ese
tópico y se empareja por client_id y frase para MOSTRAR LA CAUSA al operador.
"""
import threading
import time
from collections import deque
from dataclasses import dataclass

from rclpy.action import ActionClient
from std_msgs.msg import String

from arm_broker_interfaces.action import PickPlace
from jetcobot_interfaces.srv import InterpretarOrden

# Gran Reto (1 = alta, 2 = normal, 3 = baja)  ->  broker RB-2 (0 = mas alta ... 2 = mas baja)
PRIORIDAD_A_BROKER = {1: 0, 2: 1, 3: 2}


@dataclass
class Ack:
    aceptada: bool
    causa: str = ""
    id_orden: int = 0
    posicion_en_cola: int = 0


class PuenteOrdenes:
    def __init__(self, nodo, origen: str, timeout_servicio_s: float = 8.0,
                 espera_rechazo_s: float = 1.5):
        self.nodo, self.origen = nodo, origen
        self.timeout_servicio_s, self.espera_rechazo_s = timeout_servicio_s, espera_rechazo_s
        self.cli_interp = nodo.create_client(InterpretarOrden, "/interpretar_orden")
        self.ac = ActionClient(nodo, PickPlace, "/arm/pick_place")
        self._rechazos = deque(maxlen=100)
        self._cv = threading.Condition()
        nodo.create_subscription(String, "/arm/rejections", self._on_rechazo, 50)

    def _on_rechazo(self, msg):
        partes = msg.data.split("|", 2)
        if len(partes) == 3:
            with self._cv:
                self._rechazos.append((partes[0], partes[1], partes[2]))
                self._cv.notify_all()

    def esperar_servicios(self, espera_s: float = 20.0) -> bool:
        ok = self.cli_interp.wait_for_service(timeout_sec=espera_s)
        if not ok:
            self.nodo.get_logger().error("Servicio /interpretar_orden no disponible")
        if not self.ac.wait_for_server(timeout_sec=espera_s):
            self.nodo.get_logger().error("Accion /arm/pick_place no disponible (¿arm_broker?)")
            ok = False
        return ok

    def _esperar(self, futuro, timeout_s):
        listo = threading.Event()
        futuro.add_done_callback(lambda _f: listo.set())
        return futuro.result() if listo.wait(timeout_s) else None

    def _causa_rechazo(self, frase: str) -> str:
        fin = time.monotonic() + self.espera_rechazo_s
        with self._cv:
            while True:
                for cli, codigo, motivo in reversed(self._rechazos):
                    if cli == self.origen and frase in motivo:
                        return f"{codigo}: {motivo}"
                resto = fin - time.monotonic()
                if resto <= 0:
                    return "rechazada (motivo no recibido; ver /arm/rejections y rechazos.csv)"
                self._cv.wait(resto)

    def procesar(self, frase: str, t_fin_habla: float = 0.0, captura_ms: float = 0.0,
                 transcripcion_ms: float = 0.0) -> dict:
        """Devuelve {'decision', 'broker': Ack} o {'error': ...}. No espera a que el
        brazo termine: el resultado final se informa por el log cuando llegue."""
        req = InterpretarOrden.Request()
        req.frase = frase
        t0 = time.time()
        dec = self._esperar(self.cli_interp.call_async(req), self.timeout_servicio_s)
        if dec is None:
            return {"error": "timeout esperando /interpretar_orden"}
        decision_ms = (time.time() - t0) * 1000.0

        g = PickPlace.Goal()
        g.client_id = self.origen
        # La prioridad viene de la decision del MODELO; el cliente solo traduce la escala.
        g.priority = PRIORIDAD_A_BROKER.get(int(dec.prioridad), 1)
        g.accion, g.objeto, g.color, g.zona = dec.accion, dec.objeto, dec.color, dec.zona
        g.frase, g.permitido, g.causa_decision = frase, bool(dec.permitido), dec.causa
        g.degradado, g.fuente = bool(dec.degradado), dec.fuente
        g.t_fin_habla, g.captura_ms = float(t_fin_habla), float(captura_ms)
        g.transcripcion_ms, g.decision_ms = float(transcripcion_ms), decision_ms

        gh = self._esperar(self.ac.send_goal_async(g), self.timeout_servicio_s)
        if gh is None:
            return {"decision": dec, "error": "timeout esperando al broker"}
        if not gh.accepted:
            return {"decision": dec, "broker": Ack(False, self._causa_rechazo(frase)),
                    "decision_ms": decision_ms}
        gh.get_result_async().add_done_callback(
            lambda f, fr=frase: self._on_resultado(fr, f))
        return {"decision": dec, "broker": Ack(True), "decision_ms": decision_ms}

    def _on_resultado(self, frase, futuro):
        r = futuro.result().result
        self.nodo.get_logger().info(
            f"[RESULTADO] '{frase}': {'OK' if r.success else 'FALLO'} - {r.message} | "
            f"error FK={r.error_fk_mm:.1f} mm | voz→movimiento={r.voz_a_movimiento_ms:.0f} ms")

    @staticmethod
    def resumen(r: dict) -> str:
        if "error" in r and "decision" not in r:
            return f"ERROR: {r['error']}"
        d = r["decision"]
        base = (f"decisión[{d.fuente}{' DEGRADADO' if d.degradado else ''}]: "
                f"{d.accion}/{d.objeto}/{d.color}/{d.zona} prio={d.prioridad} "
                f"permitido={d.permitido}")
        if "broker" not in r:
            return base + f" | {r['error']}"
        b = r["broker"]
        return base + (" -> ACEPTADA, en la cola del broker" if b.aceptada
                       else f" -> RECHAZADA antes de encolar: {b.causa}")
