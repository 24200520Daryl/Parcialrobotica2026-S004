"""Cliente HTTP del servidor LAYA (sin ROS, para poder probarlo aislado).

Protocolo (repositorio oficial NandhaKishorM/laya, `laya-serve`):
    POST /v1/systemone
    {"state": {...}, "questions": {id: {type, instructions, criteria}}, "model": "..."}
    -> {"answers": {id: {"choice": ..} | {"score": ..} | {"noul": ..}}, "usage": {...}}

Idea central: se hacen PREGUNTAS TIPADAS (choice / score / noul). El modelo
puntúa opciones en un único paso hacia adelante: no genera texto, así que no hay
nada que parsear ni que alucinar.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturoTimeout
from dataclasses import dataclass
from typing import Dict, Optional, Sequence

import requests

from .clasificador_palabras import (ACCION_DESCONOCIDA, ACCION_INICIO,
                                    ACCION_RECOGER, NINGUNO, Decision)

CLAVES_MS = ("latency_ms", "elapsed_ms", "compute_ms", "server_ms", "inference_ms")


class LayaError(Exception):
    """Cualquier fallo de LAYA (red, HTTP, formato). Activa el modo degradado."""


class LayaTimeout(LayaError):
    """LAYA no respondió dentro del tiempo límite."""


@dataclass
class ResultadoLaya:
    decision: Decision
    total_ms: float                 # tiempo HTTP medido por el cliente (ida y vuelta)
    computo_ms: Optional[float]     # lo que informa el propio servidor (None si no lo da)
    red_ms: Optional[float]         # total - computo  (None si no hay computo)


def _conf(resp: dict) -> float:
    """Probabilidad de la respuesta elegida (answer_confidence si existe)."""
    if isinstance(resp.get("answer_confidence"), (int, float)):
        return float(resp["answer_confidence"])
    probs = resp.get("probabilities")
    if isinstance(probs, dict) and resp.get("choice") in probs:
        return float(probs[resp["choice"]])
    return 0.0


class LayaCliente:
    def __init__(self, host: str, puerto: int, endpoint: str = "/v1/systemone",
                 modelo: str = "multilingual", preset: str = "",
                 api_key: Optional[str] = None, usar_https: bool = False,
                 colores: Sequence[str] = (), objetos: Sequence[str] = (),
                 zonas: Sequence[str] = (), umbral_prohibida: float = 0.5):
        esquema = "https" if usar_https else "http"
        self.url = f"{esquema}://{host}:{puerto}{endpoint}"
        self.modelo, self.preset = modelo, preset
        self.colores, self.objetos, self.zonas = list(colores), list(objetos), list(zonas)
        self.umbral_prohibida = umbral_prohibida
        self.headers = {"Content-Type": "application/json"}
        if api_key:  # opcional: solo si el servidor del lab exige Bearer
            self.headers["Authorization"] = f"Bearer {api_key}"
        self._local = threading.local()
        self._pool = ThreadPoolExecutor(max_workers=16, thread_name_prefix="laya")

    # ------------------------------------------------------------------ payload
    @staticmethod
    def _opciones(nombres: Sequence[str], que: str) -> dict:
        d = {n: f"{que} {n}" for n in nombres}
        d[NINGUNO] = f"no se menciona ningun {que}"
        return d

    def construir_payload(self, frase: str) -> dict:
        q = {
            "accion": {
                        "type": "choice",
                        "instructions": (
                            "Clasifica la intención de la orden del operador. "
                            "Si pide recoger, tomar, coger, mover, llevar o trasladar "
                            "un objeto desde una posición de la mesa hasta una zona "
                            "de destino, selecciona recoger_y_colocar. "
                            "Selecciona ir_inicio solamente si pide explícitamente "
                            "volver al inicio, regresar al origen o ir a la posición "
                            "de reposo. Si no corresponde a ninguna de estas acciones, "
                            "selecciona desconocida."
                        ),
                        "criteria": {
                            ACCION_RECOGER: (
                                "recoger_y_colocar: recoger un objeto de la mesa y "
                                "transportarlo a la zona de destino indicada"
                            ),
                            ACCION_INICIO: (
                                "ir_inicio: regresar explícitamente a la posición "
                                "inicial o de reposo, sin ejecutar una tarea de transporte"
                            ),
                            ACCION_DESCONOCIDA: (
                                "desconocida: orden que no corresponde a recoger y colocar "
                                "ni a regresar al inicio"
                            ),
                        },
                    },
            "objeto": {"type": "choice",
                       "instructions": "Que objeto menciona la orden?",
                       "criteria": self._opciones(self.objetos, "objeto")},
            "color": {
                            "type": "choice",
                            "instructions": (
                                "Identifica la posición de origen del objeto en la mesa. "
                                "Si dice posición 1, selecciona P1; posición 2, P2; "
                                "posición 3, P3; posición 4, P4. "
                                "No confundas la posición de origen con la zona de destino. "
                                "Si no se menciona la posición, selecciona ninguno."
                            ),
                            "criteria": self._opciones(self.colores, "posición de origen"),
                        },
            "zona": {"type": "choice",
                     "instructions": "En que zona hay que dejar el objeto?",
                     "criteria": self._opciones(self.zonas, "zona")},
            "urgencia": {"type": "score",
                         "instructions": "Que tan urgente es la orden?",
                         "criteria": ["sin prisa", "normal", "urgente"]},
            "prohibida": {"type": "noul",
                          "instructions": "La orden pide algo peligroso o no permitido: "
                                          "golpear, lanzar, tirar al suelo, romper, "
                                          "danar o apagar el sistema."},
        }
        payload = {"state": {"orden": frase}, "questions": q}
        if self.modelo:
            payload["model"] = self.modelo      # 'multilingual' para español
        if self.preset:
            payload["preset"] = self.preset     # solo si el docente lo exige
        return payload

    # --------------------------------------------------------------------- HTTP
    def _sesion(self) -> requests.Session:
        if not hasattr(self._local, "s"):
            self._local.s = requests.Session()   # keep-alive: menos RTT
        return self._local.s

    def _post(self, payload: dict, timeout_s: float):
        t0 = time.perf_counter()
        r = self._sesion().post(self.url, json=payload, headers=self.headers,
                                timeout=(timeout_s, timeout_s))
        total_ms = (time.perf_counter() - t0) * 1000.0
        if r.status_code != 200:
            raise LayaError(f"HTTP {r.status_code}: {r.text[:100]}")
        try:
            js = r.json()
        except ValueError as e:
            raise LayaError("la respuesta no es JSON") from e
        return js, total_ms, r.headers

    def consultar(self, frase: str, timeout_s: float) -> ResultadoLaya:
        """Devuelve la decisión o lanza LayaTimeout/LayaError. NUNCA espera más
        de ~timeout_s: el deadline se impone desde fuera del hilo HTTP."""
        fut = self._pool.submit(self._post, self.construir_payload(frase), timeout_s)
        try:
            js, total_ms, headers = fut.result(timeout=timeout_s)
        except FuturoTimeout:
            fut.cancel()
            raise LayaTimeout(f"sin respuesta en {timeout_s:.2f} s") from None
        except requests.exceptions.Timeout:
            raise LayaTimeout(f"timeout HTTP ({timeout_s:.2f} s)") from None
        except requests.exceptions.RequestException as e:
            raise LayaError(f"red: {type(e).__name__}") from None
        return self._interpretar(js, total_ms, headers)

    # ---------------------------------------------------------------- respuesta
    @staticmethod
    def _extraer_computo_ms(js: dict, headers) -> Optional[float]:
        for cont in (js, js.get("usage"), js.get("routing"), js.get("timing"),
                     js.get("meta")):
            if isinstance(cont, dict):
                for k in CLAVES_MS:
                    v = cont.get(k)
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        return float(v)
        try:
            return float(headers.get("X-Process-Time-Ms"))
        except (TypeError, ValueError):
            return None

    def _interpretar(self, js: dict, total_ms: float, headers) -> ResultadoLaya:
        ans = js.get("answers") if isinstance(js, dict) else None
        if not isinstance(ans, dict):
            raise LayaError("la respuesta no trae 'answers'")
        try:
            d = Decision(
                accion=ans["accion"]["choice"],
                objeto=ans["objeto"]["choice"],
                color=ans["color"]["choice"],
                zona=ans["zona"]["choice"],
            )
            urgencia = float(ans["urgencia"]["score"])          # esperado en [0, 2]
            p_prohibida = float(ans["prohibida"]["noul"])        # P(es prohibida)
        except (KeyError, TypeError, ValueError) as e:
            raise LayaError(f"respuesta incompleta: {e!r}") from None

        d.prioridad = max(1, min(3, 3 - int(round(urgencia))))   # urgente(2) -> 1
        d.permitido = p_prohibida < self.umbral_prohibida
        d.causa = "" if d.permitido else f"LAYA: P(prohibida)={p_prohibida:.2f}"
        confs = [_conf(ans[k]) for k in ("accion", "objeto", "color", "zona")]
        d.confianza = round(min(confs), 3)

        comp = self._extraer_computo_ms(js, headers)
        red = max(total_ms - comp, 0.0) if comp is not None else None
        return ResultadoLaya(d, total_ms, comp, red)
