"""Captura de micrófono con detección simple de fin de frase (sin ROS).

Devuelve las marcas de tiempo necesarias para la Parte C del examen:
  t_fin_habla   : instante de la última ventana con voz (cuando el operador termina)
  t_fin_captura : instante en que se cierra la grabación (t_fin_habla + silencio)
  => captura_ms = (t_fin_captura - t_fin_habla) * 1000
"""
from __future__ import annotations

import time
import wave
from dataclasses import dataclass


class SinVoz(Exception):
    pass


@dataclass
class Captura:
    ruta: str
    t_fin_habla: float
    t_fin_captura: float

    @property
    def captura_ms(self) -> float:
        return (self.t_fin_captura - self.t_fin_habla) * 1000.0


def guardar_wav(ruta: str, pcm16_bytes: bytes, fs: int = 16000) -> None:
    with wave.open(ruta, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(fs)
        w.writeframes(pcm16_bytes)


def grabar_microfono(ruta_wav: str, fs: int = 16000, max_s: float = 10.0,
                     silencio_fin_s: float = 0.8, umbral_rms: float = 500.0,
                     espera_voz_s: float = 15.0, dispositivo=None) -> Captura:
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("Falta 'sounddevice'. Instala: sudo apt install "
                           "libportaudio2 && pip3 install sounddevice") from e

    bloque = int(fs * 0.1)  # ventanas de 100 ms
    trozos, hablando = [], False
    t_ini = t_voz = time.time()
    with sd.InputStream(samplerate=fs, channels=1, dtype="int16",
                        blocksize=bloque, device=dispositivo) as st:
        while True:
            datos, _ = st.read(bloque)
            ahora = time.time()
            trozos.append(datos.copy())
            rms = float(np.sqrt(np.mean(datos.astype(np.float32) ** 2)))
            if rms > umbral_rms:
                hablando, t_voz = True, ahora
            if hablando and ahora - t_voz >= silencio_fin_s:
                break
            if hablando and ahora - t_ini >= max_s:
                t_voz = ahora        # cortado por duración máxima
                break
            if not hablando and ahora - t_ini >= espera_voz_s:
                raise SinVoz("no se detectó voz")
    guardar_wav(ruta_wav, np.concatenate(trozos).tobytes(), fs)
    return Captura(ruta_wav, t_voz, time.time())
