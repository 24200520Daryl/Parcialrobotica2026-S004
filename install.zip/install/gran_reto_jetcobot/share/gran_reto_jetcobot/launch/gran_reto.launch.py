"""Lanza interprete_ordenes + el arm_broker de RB-2 (ya extendido con /arm/pick_place).
transcriptor_voz y cliente_ordenes son interactivos: correlos en su propia terminal.

  ros2 launch gran_reto_jetcobot gran_reto.launch.py laya_host:=192.168.1.50 \
       laya_puerto:=8000 timeout_s:=2.0 politica:=aging
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    share = get_package_share_directory("gran_reto_jetcobot")
    args = [DeclareLaunchArgument(n, default_value=v) for n, v in (
        ("laya_host", "172.51.1.2"), ("laya_puerto", "8000"), ("timeout_s", "2.0"),
        ("politica", "aging"))]
    return LaunchDescription(args + [
        Node(package="gran_reto_jetcobot", executable="interprete_ordenes",
             name="interprete_ordenes", output="screen",
             parameters=[os.path.join(share, "config", "params.yaml"),
                         {"laya_host": LaunchConfiguration("laya_host"),
                          "laya_puerto": LaunchConfiguration("laya_puerto"),
                          "timeout_s": LaunchConfiguration("timeout_s")}]),
        Node(package="arm_broker", executable="arm_broker", name="arm_broker",
             output="screen",
             parameters=[os.path.join(share, "config", "arm_broker_gran_reto.yaml"),
                         {"policy": LaunchConfiguration("politica")}]),
    ])
