# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(jetcobot_interfaces_IDL_FILES "srv/InterpretarOrden.idl")
set(jetcobot_interfaces_INTERFACE_FILES "srv/InterpretarOrden.srv;srv/InterpretarOrden_Request.msg;srv/InterpretarOrden_Response.msg")
