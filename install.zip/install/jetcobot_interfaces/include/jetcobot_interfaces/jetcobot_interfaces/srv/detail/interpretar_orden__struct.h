﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice

#ifndef JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_H_
#define JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'frase'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/InterpretarOrden in the package jetcobot_interfaces.
typedef struct jetcobot_interfaces__srv__InterpretarOrden_Request
{
  rosidl_runtime_c__String frase;
} jetcobot_interfaces__srv__InterpretarOrden_Request;

// Struct for a sequence of jetcobot_interfaces__srv__InterpretarOrden_Request.
typedef struct jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence
{
  jetcobot_interfaces__srv__InterpretarOrden_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'accion'
// Member 'objeto'
// Member 'color'
// Member 'zona'
// Member 'causa'
// Member 'fuente'
// Member 'detalle'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/InterpretarOrden in the package jetcobot_interfaces.
typedef struct jetcobot_interfaces__srv__InterpretarOrden_Response
{
  /// recoger_y_colocar | ir_inicio | desconocida
  rosidl_runtime_c__String accion;
  /// nombre del objeto o "ninguno"
  rosidl_runtime_c__String objeto;
  /// color del objeto o "ninguno"
  rosidl_runtime_c__String color;
  /// zona de depósito o "ninguno"
  rosidl_runtime_c__String zona;
  /// 1 = alta, 2 = normal, 3 = baja (menor número sale primero)
  int32_t prioridad;
  /// false => el broker debe rechazarla antes de encolar
  bool permitido;
  /// por qué no es permitida (vacío si permitido)
  rosidl_runtime_c__String causa;
  /// 0..1 (aprox.; del modelo o heurística)
  double confianza;
  /// --- Trazabilidad del método usado ---
  /// true => LAYA no respondió a tiempo, se usó palabras clave
  bool degradado;
  /// "laya" | "palabras_clave"
  rosidl_runtime_c__String fuente;
  /// motivo de la degradación o información extra
  rosidl_runtime_c__String detalle;
  /// --- Latencias en ms (-1.0 = no disponible) ---
  /// tiempo total del servicio (incluye la espera si hubo timeout)
  double latencia_total_ms;
  /// RTT de red + HTTP  = http_total - computo_servidor
  double latencia_red_ms;
  /// tiempo de cálculo informado por el propio servidor LAYA
  double latencia_computo_ms;
} jetcobot_interfaces__srv__InterpretarOrden_Response;

// Struct for a sequence of jetcobot_interfaces__srv__InterpretarOrden_Response.
typedef struct jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence
{
  jetcobot_interfaces__srv__InterpretarOrden_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_H_
