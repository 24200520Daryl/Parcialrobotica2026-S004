// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice
#include "jetcobot_interfaces/srv/detail/interpretar_orden__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `frase`
#include "rosidl_runtime_c/string_functions.h"

bool
jetcobot_interfaces__srv__InterpretarOrden_Request__init(jetcobot_interfaces__srv__InterpretarOrden_Request * msg)
{
  if (!msg) {
    return false;
  }
  // frase
  if (!rosidl_runtime_c__String__init(&msg->frase)) {
    jetcobot_interfaces__srv__InterpretarOrden_Request__fini(msg);
    return false;
  }
  return true;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Request__fini(jetcobot_interfaces__srv__InterpretarOrden_Request * msg)
{
  if (!msg) {
    return;
  }
  // frase
  rosidl_runtime_c__String__fini(&msg->frase);
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Request__are_equal(const jetcobot_interfaces__srv__InterpretarOrden_Request * lhs, const jetcobot_interfaces__srv__InterpretarOrden_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // frase
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->frase), &(rhs->frase)))
  {
    return false;
  }
  return true;
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Request__copy(
  const jetcobot_interfaces__srv__InterpretarOrden_Request * input,
  jetcobot_interfaces__srv__InterpretarOrden_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // frase
  if (!rosidl_runtime_c__String__copy(
      &(input->frase), &(output->frase)))
  {
    return false;
  }
  return true;
}

jetcobot_interfaces__srv__InterpretarOrden_Request *
jetcobot_interfaces__srv__InterpretarOrden_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Request * msg = (jetcobot_interfaces__srv__InterpretarOrden_Request *)allocator.allocate(sizeof(jetcobot_interfaces__srv__InterpretarOrden_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(jetcobot_interfaces__srv__InterpretarOrden_Request));
  bool success = jetcobot_interfaces__srv__InterpretarOrden_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Request__destroy(jetcobot_interfaces__srv__InterpretarOrden_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    jetcobot_interfaces__srv__InterpretarOrden_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__init(jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Request * data = NULL;

  if (size) {
    data = (jetcobot_interfaces__srv__InterpretarOrden_Request *)allocator.zero_allocate(size, sizeof(jetcobot_interfaces__srv__InterpretarOrden_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = jetcobot_interfaces__srv__InterpretarOrden_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        jetcobot_interfaces__srv__InterpretarOrden_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__fini(jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      jetcobot_interfaces__srv__InterpretarOrden_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence *
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * array = (jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence *)allocator.allocate(sizeof(jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__destroy(jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__are_equal(const jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * lhs, const jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!jetcobot_interfaces__srv__InterpretarOrden_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence__copy(
  const jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * input,
  jetcobot_interfaces__srv__InterpretarOrden_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(jetcobot_interfaces__srv__InterpretarOrden_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    jetcobot_interfaces__srv__InterpretarOrden_Request * data =
      (jetcobot_interfaces__srv__InterpretarOrden_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!jetcobot_interfaces__srv__InterpretarOrden_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          jetcobot_interfaces__srv__InterpretarOrden_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!jetcobot_interfaces__srv__InterpretarOrden_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `accion`
// Member `objeto`
// Member `color`
// Member `zona`
// Member `causa`
// Member `fuente`
// Member `detalle`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

bool
jetcobot_interfaces__srv__InterpretarOrden_Response__init(jetcobot_interfaces__srv__InterpretarOrden_Response * msg)
{
  if (!msg) {
    return false;
  }
  // accion
  if (!rosidl_runtime_c__String__init(&msg->accion)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // objeto
  if (!rosidl_runtime_c__String__init(&msg->objeto)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // color
  if (!rosidl_runtime_c__String__init(&msg->color)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // zona
  if (!rosidl_runtime_c__String__init(&msg->zona)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // prioridad
  // permitido
  // causa
  if (!rosidl_runtime_c__String__init(&msg->causa)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // confianza
  // degradado
  // fuente
  if (!rosidl_runtime_c__String__init(&msg->fuente)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // detalle
  if (!rosidl_runtime_c__String__init(&msg->detalle)) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
    return false;
  }
  // latencia_total_ms
  // latencia_red_ms
  // latencia_computo_ms
  return true;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Response__fini(jetcobot_interfaces__srv__InterpretarOrden_Response * msg)
{
  if (!msg) {
    return;
  }
  // accion
  rosidl_runtime_c__String__fini(&msg->accion);
  // objeto
  rosidl_runtime_c__String__fini(&msg->objeto);
  // color
  rosidl_runtime_c__String__fini(&msg->color);
  // zona
  rosidl_runtime_c__String__fini(&msg->zona);
  // prioridad
  // permitido
  // causa
  rosidl_runtime_c__String__fini(&msg->causa);
  // confianza
  // degradado
  // fuente
  rosidl_runtime_c__String__fini(&msg->fuente);
  // detalle
  rosidl_runtime_c__String__fini(&msg->detalle);
  // latencia_total_ms
  // latencia_red_ms
  // latencia_computo_ms
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Response__are_equal(const jetcobot_interfaces__srv__InterpretarOrden_Response * lhs, const jetcobot_interfaces__srv__InterpretarOrden_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // accion
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->accion), &(rhs->accion)))
  {
    return false;
  }
  // objeto
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->objeto), &(rhs->objeto)))
  {
    return false;
  }
  // color
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->color), &(rhs->color)))
  {
    return false;
  }
  // zona
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->zona), &(rhs->zona)))
  {
    return false;
  }
  // prioridad
  if (lhs->prioridad != rhs->prioridad) {
    return false;
  }
  // permitido
  if (lhs->permitido != rhs->permitido) {
    return false;
  }
  // causa
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->causa), &(rhs->causa)))
  {
    return false;
  }
  // confianza
  if (lhs->confianza != rhs->confianza) {
    return false;
  }
  // degradado
  if (lhs->degradado != rhs->degradado) {
    return false;
  }
  // fuente
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->fuente), &(rhs->fuente)))
  {
    return false;
  }
  // detalle
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->detalle), &(rhs->detalle)))
  {
    return false;
  }
  // latencia_total_ms
  if (lhs->latencia_total_ms != rhs->latencia_total_ms) {
    return false;
  }
  // latencia_red_ms
  if (lhs->latencia_red_ms != rhs->latencia_red_ms) {
    return false;
  }
  // latencia_computo_ms
  if (lhs->latencia_computo_ms != rhs->latencia_computo_ms) {
    return false;
  }
  return true;
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Response__copy(
  const jetcobot_interfaces__srv__InterpretarOrden_Response * input,
  jetcobot_interfaces__srv__InterpretarOrden_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // accion
  if (!rosidl_runtime_c__String__copy(
      &(input->accion), &(output->accion)))
  {
    return false;
  }
  // objeto
  if (!rosidl_runtime_c__String__copy(
      &(input->objeto), &(output->objeto)))
  {
    return false;
  }
  // color
  if (!rosidl_runtime_c__String__copy(
      &(input->color), &(output->color)))
  {
    return false;
  }
  // zona
  if (!rosidl_runtime_c__String__copy(
      &(input->zona), &(output->zona)))
  {
    return false;
  }
  // prioridad
  output->prioridad = input->prioridad;
  // permitido
  output->permitido = input->permitido;
  // causa
  if (!rosidl_runtime_c__String__copy(
      &(input->causa), &(output->causa)))
  {
    return false;
  }
  // confianza
  output->confianza = input->confianza;
  // degradado
  output->degradado = input->degradado;
  // fuente
  if (!rosidl_runtime_c__String__copy(
      &(input->fuente), &(output->fuente)))
  {
    return false;
  }
  // detalle
  if (!rosidl_runtime_c__String__copy(
      &(input->detalle), &(output->detalle)))
  {
    return false;
  }
  // latencia_total_ms
  output->latencia_total_ms = input->latencia_total_ms;
  // latencia_red_ms
  output->latencia_red_ms = input->latencia_red_ms;
  // latencia_computo_ms
  output->latencia_computo_ms = input->latencia_computo_ms;
  return true;
}

jetcobot_interfaces__srv__InterpretarOrden_Response *
jetcobot_interfaces__srv__InterpretarOrden_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Response * msg = (jetcobot_interfaces__srv__InterpretarOrden_Response *)allocator.allocate(sizeof(jetcobot_interfaces__srv__InterpretarOrden_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(jetcobot_interfaces__srv__InterpretarOrden_Response));
  bool success = jetcobot_interfaces__srv__InterpretarOrden_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Response__destroy(jetcobot_interfaces__srv__InterpretarOrden_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__init(jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Response * data = NULL;

  if (size) {
    data = (jetcobot_interfaces__srv__InterpretarOrden_Response *)allocator.zero_allocate(size, sizeof(jetcobot_interfaces__srv__InterpretarOrden_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = jetcobot_interfaces__srv__InterpretarOrden_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        jetcobot_interfaces__srv__InterpretarOrden_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__fini(jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      jetcobot_interfaces__srv__InterpretarOrden_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence *
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * array = (jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence *)allocator.allocate(sizeof(jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__destroy(jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__are_equal(const jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * lhs, const jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!jetcobot_interfaces__srv__InterpretarOrden_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence__copy(
  const jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * input,
  jetcobot_interfaces__srv__InterpretarOrden_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(jetcobot_interfaces__srv__InterpretarOrden_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    jetcobot_interfaces__srv__InterpretarOrden_Response * data =
      (jetcobot_interfaces__srv__InterpretarOrden_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!jetcobot_interfaces__srv__InterpretarOrden_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          jetcobot_interfaces__srv__InterpretarOrden_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!jetcobot_interfaces__srv__InterpretarOrden_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
