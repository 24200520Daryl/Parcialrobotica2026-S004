// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice

#ifndef JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TYPE_SUPPORT_H_
#define JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "jetcobot_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_jetcobot_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  jetcobot_interfaces,
  srv,
  InterpretarOrden_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_jetcobot_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  jetcobot_interfaces,
  srv,
  InterpretarOrden_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_jetcobot_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  jetcobot_interfaces,
  srv,
  InterpretarOrden
)();

#ifdef __cplusplus
}
#endif

#endif  // JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TYPE_SUPPORT_H_
