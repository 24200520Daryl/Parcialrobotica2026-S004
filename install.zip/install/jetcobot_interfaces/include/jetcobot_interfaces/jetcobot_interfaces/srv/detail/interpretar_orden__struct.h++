// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice

#ifndef JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_HPP_
#define JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Request __attribute__((deprecated))
#else
# define DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Request __declspec(deprecated)
#endif

namespace jetcobot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct InterpretarOrden_Request_
{
  using Type = InterpretarOrden_Request_<ContainerAllocator>;

  explicit InterpretarOrden_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frase = "";
    }
  }

  explicit InterpretarOrden_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : frase(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frase = "";
    }
  }

  // field types and members
  using _frase_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _frase_type frase;

  // setters for named parameter idiom
  Type & set__frase(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->frase = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Request
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Request
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const InterpretarOrden_Request_ & other) const
  {
    if (this->frase != other.frase) {
      return false;
    }
    return true;
  }
  bool operator!=(const InterpretarOrden_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct InterpretarOrden_Request_

// alias to use template instance with default allocator
using InterpretarOrden_Request =
  jetcobot_interfaces::srv::InterpretarOrden_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace jetcobot_interfaces


#ifndef _WIN32
# define DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Response __attribute__((deprecated))
#else
# define DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Response __declspec(deprecated)
#endif

namespace jetcobot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct InterpretarOrden_Response_
{
  using Type = InterpretarOrden_Response_<ContainerAllocator>;

  explicit InterpretarOrden_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accion = "";
      this->objeto = "";
      this->color = "";
      this->zona = "";
      this->prioridad = 0l;
      this->permitido = false;
      this->causa = "";
      this->confianza = 0.0;
      this->degradado = false;
      this->fuente = "";
      this->detalle = "";
      this->latencia_total_ms = 0.0;
      this->latencia_red_ms = 0.0;
      this->latencia_computo_ms = 0.0;
    }
  }

  explicit InterpretarOrden_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : accion(_alloc),
    objeto(_alloc),
    color(_alloc),
    zona(_alloc),
    causa(_alloc),
    fuente(_alloc),
    detalle(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accion = "";
      this->objeto = "";
      this->color = "";
      this->zona = "";
      this->prioridad = 0l;
      this->permitido = false;
      this->causa = "";
      this->confianza = 0.0;
      this->degradado = false;
      this->fuente = "";
      this->detalle = "";
      this->latencia_total_ms = 0.0;
      this->latencia_red_ms = 0.0;
      this->latencia_computo_ms = 0.0;
    }
  }

  // field types and members
  using _accion_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _accion_type accion;
  using _objeto_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _objeto_type objeto;
  using _color_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _color_type color;
  using _zona_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _zona_type zona;
  using _prioridad_type =
    int32_t;
  _prioridad_type prioridad;
  using _permitido_type =
    bool;
  _permitido_type permitido;
  using _causa_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _causa_type causa;
  using _confianza_type =
    double;
  _confianza_type confianza;
  using _degradado_type =
    bool;
  _degradado_type degradado;
  using _fuente_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _fuente_type fuente;
  using _detalle_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _detalle_type detalle;
  using _latencia_total_ms_type =
    double;
  _latencia_total_ms_type latencia_total_ms;
  using _latencia_red_ms_type =
    double;
  _latencia_red_ms_type latencia_red_ms;
  using _latencia_computo_ms_type =
    double;
  _latencia_computo_ms_type latencia_computo_ms;

  // setters for named parameter idiom
  Type & set__accion(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->accion = _arg;
    return *this;
  }
  Type & set__objeto(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->objeto = _arg;
    return *this;
  }
  Type & set__color(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->color = _arg;
    return *this;
  }
  Type & set__zona(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->zona = _arg;
    return *this;
  }
  Type & set__prioridad(
    const int32_t & _arg)
  {
    this->prioridad = _arg;
    return *this;
  }
  Type & set__permitido(
    const bool & _arg)
  {
    this->permitido = _arg;
    return *this;
  }
  Type & set__causa(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->causa = _arg;
    return *this;
  }
  Type & set__confianza(
    const double & _arg)
  {
    this->confianza = _arg;
    return *this;
  }
  Type & set__degradado(
    const bool & _arg)
  {
    this->degradado = _arg;
    return *this;
  }
  Type & set__fuente(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->fuente = _arg;
    return *this;
  }
  Type & set__detalle(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->detalle = _arg;
    return *this;
  }
  Type & set__latencia_total_ms(
    const double & _arg)
  {
    this->latencia_total_ms = _arg;
    return *this;
  }
  Type & set__latencia_red_ms(
    const double & _arg)
  {
    this->latencia_red_ms = _arg;
    return *this;
  }
  Type & set__latencia_computo_ms(
    const double & _arg)
  {
    this->latencia_computo_ms = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Response
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__jetcobot_interfaces__srv__InterpretarOrden_Response
    std::shared_ptr<jetcobot_interfaces::srv::InterpretarOrden_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const InterpretarOrden_Response_ & other) const
  {
    if (this->accion != other.accion) {
      return false;
    }
    if (this->objeto != other.objeto) {
      return false;
    }
    if (this->color != other.color) {
      return false;
    }
    if (this->zona != other.zona) {
      return false;
    }
    if (this->prioridad != other.prioridad) {
      return false;
    }
    if (this->permitido != other.permitido) {
      return false;
    }
    if (this->causa != other.causa) {
      return false;
    }
    if (this->confianza != other.confianza) {
      return false;
    }
    if (this->degradado != other.degradado) {
      return false;
    }
    if (this->fuente != other.fuente) {
      return false;
    }
    if (this->detalle != other.detalle) {
      return false;
    }
    if (this->latencia_total_ms != other.latencia_total_ms) {
      return false;
    }
    if (this->latencia_red_ms != other.latencia_red_ms) {
      return false;
    }
    if (this->latencia_computo_ms != other.latencia_computo_ms) {
      return false;
    }
    return true;
  }
  bool operator!=(const InterpretarOrden_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct InterpretarOrden_Response_

// alias to use template instance with default allocator
using InterpretarOrden_Response =
  jetcobot_interfaces::srv::InterpretarOrden_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace jetcobot_interfaces

namespace jetcobot_interfaces
{

namespace srv
{

struct InterpretarOrden
{
  using Request = jetcobot_interfaces::srv::InterpretarOrden_Request;
  using Response = jetcobot_interfaces::srv::InterpretarOrden_Response;
};

}  // namespace srv

}  // namespace jetcobot_interfaces

#endif  // JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__STRUCT_HPP_
