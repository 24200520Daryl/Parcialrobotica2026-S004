// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice

#ifndef JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__BUILDER_HPP_
#define JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "jetcobot_interfaces/srv/detail/interpretar_orden__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace jetcobot_interfaces
{

namespace srv
{

namespace builder
{

class Init_InterpretarOrden_Request_frase
{
public:
  Init_InterpretarOrden_Request_frase()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::jetcobot_interfaces::srv::InterpretarOrden_Request frase(::jetcobot_interfaces::srv::InterpretarOrden_Request::_frase_type arg)
  {
    msg_.frase = std::move(arg);
    return std::move(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::jetcobot_interfaces::srv::InterpretarOrden_Request>()
{
  return jetcobot_interfaces::srv::builder::Init_InterpretarOrden_Request_frase();
}

}  // namespace jetcobot_interfaces


namespace jetcobot_interfaces
{

namespace srv
{

namespace builder
{

class Init_InterpretarOrden_Response_latencia_computo_ms
{
public:
  explicit Init_InterpretarOrden_Response_latencia_computo_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  ::jetcobot_interfaces::srv::InterpretarOrden_Response latencia_computo_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response::_latencia_computo_ms_type arg)
  {
    msg_.latencia_computo_ms = std::move(arg);
    return std::move(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_latencia_red_ms
{
public:
  explicit Init_InterpretarOrden_Response_latencia_red_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_latencia_computo_ms latencia_red_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response::_latencia_red_ms_type arg)
  {
    msg_.latencia_red_ms = std::move(arg);
    return Init_InterpretarOrden_Response_latencia_computo_ms(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_latencia_total_ms
{
public:
  explicit Init_InterpretarOrden_Response_latencia_total_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_latencia_red_ms latencia_total_ms(::jetcobot_interfaces::srv::InterpretarOrden_Response::_latencia_total_ms_type arg)
  {
    msg_.latencia_total_ms = std::move(arg);
    return Init_InterpretarOrden_Response_latencia_red_ms(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_detalle
{
public:
  explicit Init_InterpretarOrden_Response_detalle(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_latencia_total_ms detalle(::jetcobot_interfaces::srv::InterpretarOrden_Response::_detalle_type arg)
  {
    msg_.detalle = std::move(arg);
    return Init_InterpretarOrden_Response_latencia_total_ms(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_fuente
{
public:
  explicit Init_InterpretarOrden_Response_fuente(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_detalle fuente(::jetcobot_interfaces::srv::InterpretarOrden_Response::_fuente_type arg)
  {
    msg_.fuente = std::move(arg);
    return Init_InterpretarOrden_Response_detalle(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_degradado
{
public:
  explicit Init_InterpretarOrden_Response_degradado(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_fuente degradado(::jetcobot_interfaces::srv::InterpretarOrden_Response::_degradado_type arg)
  {
    msg_.degradado = std::move(arg);
    return Init_InterpretarOrden_Response_fuente(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_confianza
{
public:
  explicit Init_InterpretarOrden_Response_confianza(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_degradado confianza(::jetcobot_interfaces::srv::InterpretarOrden_Response::_confianza_type arg)
  {
    msg_.confianza = std::move(arg);
    return Init_InterpretarOrden_Response_degradado(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_causa
{
public:
  explicit Init_InterpretarOrden_Response_causa(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_confianza causa(::jetcobot_interfaces::srv::InterpretarOrden_Response::_causa_type arg)
  {
    msg_.causa = std::move(arg);
    return Init_InterpretarOrden_Response_confianza(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_permitido
{
public:
  explicit Init_InterpretarOrden_Response_permitido(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_causa permitido(::jetcobot_interfaces::srv::InterpretarOrden_Response::_permitido_type arg)
  {
    msg_.permitido = std::move(arg);
    return Init_InterpretarOrden_Response_causa(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_prioridad
{
public:
  explicit Init_InterpretarOrden_Response_prioridad(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_permitido prioridad(::jetcobot_interfaces::srv::InterpretarOrden_Response::_prioridad_type arg)
  {
    msg_.prioridad = std::move(arg);
    return Init_InterpretarOrden_Response_permitido(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_zona
{
public:
  explicit Init_InterpretarOrden_Response_zona(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_prioridad zona(::jetcobot_interfaces::srv::InterpretarOrden_Response::_zona_type arg)
  {
    msg_.zona = std::move(arg);
    return Init_InterpretarOrden_Response_prioridad(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_color
{
public:
  explicit Init_InterpretarOrden_Response_color(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_zona color(::jetcobot_interfaces::srv::InterpretarOrden_Response::_color_type arg)
  {
    msg_.color = std::move(arg);
    return Init_InterpretarOrden_Response_zona(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_objeto
{
public:
  explicit Init_InterpretarOrden_Response_objeto(::jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
  : msg_(msg)
  {}
  Init_InterpretarOrden_Response_color objeto(::jetcobot_interfaces::srv::InterpretarOrden_Response::_objeto_type arg)
  {
    msg_.objeto = std::move(arg);
    return Init_InterpretarOrden_Response_color(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

class Init_InterpretarOrden_Response_accion
{
public:
  Init_InterpretarOrden_Response_accion()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_InterpretarOrden_Response_objeto accion(::jetcobot_interfaces::srv::InterpretarOrden_Response::_accion_type arg)
  {
    msg_.accion = std::move(arg);
    return Init_InterpretarOrden_Response_objeto(msg_);
  }

private:
  ::jetcobot_interfaces::srv::InterpretarOrden_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::jetcobot_interfaces::srv::InterpretarOrden_Response>()
{
  return jetcobot_interfaces::srv::builder::Init_InterpretarOrden_Response_accion();
}

}  // namespace jetcobot_interfaces

#endif  // JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__BUILDER_HPP_
