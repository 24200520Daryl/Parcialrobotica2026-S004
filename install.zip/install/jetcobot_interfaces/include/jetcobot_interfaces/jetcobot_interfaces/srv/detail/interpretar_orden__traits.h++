// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from jetcobot_interfaces:srv/InterpretarOrden.idl
// generated code does not contain a copyright notice

#ifndef JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TRAITS_HPP_
#define JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "jetcobot_interfaces/srv/detail/interpretar_orden__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace jetcobot_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const InterpretarOrden_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: frase
  {
    out << "frase: ";
    rosidl_generator_traits::value_to_yaml(msg.frase, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const InterpretarOrden_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: frase
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frase: ";
    rosidl_generator_traits::value_to_yaml(msg.frase, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const InterpretarOrden_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace jetcobot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use jetcobot_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const jetcobot_interfaces::srv::InterpretarOrden_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  jetcobot_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use jetcobot_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const jetcobot_interfaces::srv::InterpretarOrden_Request & msg)
{
  return jetcobot_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<jetcobot_interfaces::srv::InterpretarOrden_Request>()
{
  return "jetcobot_interfaces::srv::InterpretarOrden_Request";
}

template<>
inline const char * name<jetcobot_interfaces::srv::InterpretarOrden_Request>()
{
  return "jetcobot_interfaces/srv/InterpretarOrden_Request";
}

template<>
struct has_fixed_size<jetcobot_interfaces::srv::InterpretarOrden_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<jetcobot_interfaces::srv::InterpretarOrden_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<jetcobot_interfaces::srv::InterpretarOrden_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace jetcobot_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const InterpretarOrden_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: accion
  {
    out << "accion: ";
    rosidl_generator_traits::value_to_yaml(msg.accion, out);
    out << ", ";
  }

  // member: objeto
  {
    out << "objeto: ";
    rosidl_generator_traits::value_to_yaml(msg.objeto, out);
    out << ", ";
  }

  // member: color
  {
    out << "color: ";
    rosidl_generator_traits::value_to_yaml(msg.color, out);
    out << ", ";
  }

  // member: zona
  {
    out << "zona: ";
    rosidl_generator_traits::value_to_yaml(msg.zona, out);
    out << ", ";
  }

  // member: prioridad
  {
    out << "prioridad: ";
    rosidl_generator_traits::value_to_yaml(msg.prioridad, out);
    out << ", ";
  }

  // member: permitido
  {
    out << "permitido: ";
    rosidl_generator_traits::value_to_yaml(msg.permitido, out);
    out << ", ";
  }

  // member: causa
  {
    out << "causa: ";
    rosidl_generator_traits::value_to_yaml(msg.causa, out);
    out << ", ";
  }

  // member: confianza
  {
    out << "confianza: ";
    rosidl_generator_traits::value_to_yaml(msg.confianza, out);
    out << ", ";
  }

  // member: degradado
  {
    out << "degradado: ";
    rosidl_generator_traits::value_to_yaml(msg.degradado, out);
    out << ", ";
  }

  // member: fuente
  {
    out << "fuente: ";
    rosidl_generator_traits::value_to_yaml(msg.fuente, out);
    out << ", ";
  }

  // member: detalle
  {
    out << "detalle: ";
    rosidl_generator_traits::value_to_yaml(msg.detalle, out);
    out << ", ";
  }

  // member: latencia_total_ms
  {
    out << "latencia_total_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_total_ms, out);
    out << ", ";
  }

  // member: latencia_red_ms
  {
    out << "latencia_red_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_red_ms, out);
    out << ", ";
  }

  // member: latencia_computo_ms
  {
    out << "latencia_computo_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_computo_ms, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const InterpretarOrden_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: accion
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accion: ";
    rosidl_generator_traits::value_to_yaml(msg.accion, out);
    out << "\n";
  }

  // member: objeto
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "objeto: ";
    rosidl_generator_traits::value_to_yaml(msg.objeto, out);
    out << "\n";
  }

  // member: color
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "color: ";
    rosidl_generator_traits::value_to_yaml(msg.color, out);
    out << "\n";
  }

  // member: zona
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zona: ";
    rosidl_generator_traits::value_to_yaml(msg.zona, out);
    out << "\n";
  }

  // member: prioridad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "prioridad: ";
    rosidl_generator_traits::value_to_yaml(msg.prioridad, out);
    out << "\n";
  }

  // member: permitido
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "permitido: ";
    rosidl_generator_traits::value_to_yaml(msg.permitido, out);
    out << "\n";
  }

  // member: causa
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "causa: ";
    rosidl_generator_traits::value_to_yaml(msg.causa, out);
    out << "\n";
  }

  // member: confianza
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "confianza: ";
    rosidl_generator_traits::value_to_yaml(msg.confianza, out);
    out << "\n";
  }

  // member: degradado
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "degradado: ";
    rosidl_generator_traits::value_to_yaml(msg.degradado, out);
    out << "\n";
  }

  // member: fuente
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fuente: ";
    rosidl_generator_traits::value_to_yaml(msg.fuente, out);
    out << "\n";
  }

  // member: detalle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "detalle: ";
    rosidl_generator_traits::value_to_yaml(msg.detalle, out);
    out << "\n";
  }

  // member: latencia_total_ms
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latencia_total_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_total_ms, out);
    out << "\n";
  }

  // member: latencia_red_ms
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latencia_red_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_red_ms, out);
    out << "\n";
  }

  // member: latencia_computo_ms
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latencia_computo_ms: ";
    rosidl_generator_traits::value_to_yaml(msg.latencia_computo_ms, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const InterpretarOrden_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace jetcobot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use jetcobot_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const jetcobot_interfaces::srv::InterpretarOrden_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  jetcobot_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use jetcobot_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const jetcobot_interfaces::srv::InterpretarOrden_Response & msg)
{
  return jetcobot_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<jetcobot_interfaces::srv::InterpretarOrden_Response>()
{
  return "jetcobot_interfaces::srv::InterpretarOrden_Response";
}

template<>
inline const char * name<jetcobot_interfaces::srv::InterpretarOrden_Response>()
{
  return "jetcobot_interfaces/srv/InterpretarOrden_Response";
}

template<>
struct has_fixed_size<jetcobot_interfaces::srv::InterpretarOrden_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<jetcobot_interfaces::srv::InterpretarOrden_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<jetcobot_interfaces::srv::InterpretarOrden_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<jetcobot_interfaces::srv::InterpretarOrden>()
{
  return "jetcobot_interfaces::srv::InterpretarOrden";
}

template<>
inline const char * name<jetcobot_interfaces::srv::InterpretarOrden>()
{
  return "jetcobot_interfaces/srv/InterpretarOrden";
}

template<>
struct has_fixed_size<jetcobot_interfaces::srv::InterpretarOrden>
  : std::integral_constant<
    bool,
    has_fixed_size<jetcobot_interfaces::srv::InterpretarOrden_Request>::value &&
    has_fixed_size<jetcobot_interfaces::srv::InterpretarOrden_Response>::value
  >
{
};

template<>
struct has_bounded_size<jetcobot_interfaces::srv::InterpretarOrden>
  : std::integral_constant<
    bool,
    has_bounded_size<jetcobot_interfaces::srv::InterpretarOrden_Request>::value &&
    has_bounded_size<jetcobot_interfaces::srv::InterpretarOrden_Response>::value
  >
{
};

template<>
struct is_service<jetcobot_interfaces::srv::InterpretarOrden>
  : std::true_type
{
};

template<>
struct is_service_request<jetcobot_interfaces::srv::InterpretarOrden_Request>
  : std::true_type
{
};

template<>
struct is_service_response<jetcobot_interfaces::srv::InterpretarOrden_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // JETCOBOT_INTERFACES__SRV__DETAIL__INTERPRETAR_ORDEN__TRAITS_HPP_
