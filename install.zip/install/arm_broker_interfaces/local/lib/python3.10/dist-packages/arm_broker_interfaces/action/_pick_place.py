# generated from rosidl_generator_py/resource/_idl.py.em
# with input from arm_broker_interfaces:action/PickPlace.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_PickPlace_Goal(type):
    """Metaclass of message 'PickPlace_Goal'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_Goal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__goal
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__goal
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__goal
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__goal
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__goal

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_Goal(metaclass=Metaclass_PickPlace_Goal):
    """Message class 'PickPlace_Goal'."""

    __slots__ = [
        '_client_id',
        '_priority',
        '_accion',
        '_objeto',
        '_color',
        '_zona',
        '_frase',
        '_permitido',
        '_causa_decision',
        '_degradado',
        '_fuente',
        '_t_fin_habla',
        '_captura_ms',
        '_transcripcion_ms',
        '_decision_ms',
    ]

    _fields_and_field_types = {
        'client_id': 'string',
        'priority': 'uint8',
        'accion': 'string',
        'objeto': 'string',
        'color': 'string',
        'zona': 'string',
        'frase': 'string',
        'permitido': 'boolean',
        'causa_decision': 'string',
        'degradado': 'boolean',
        'fuente': 'string',
        't_fin_habla': 'double',
        'captura_ms': 'double',
        'transcripcion_ms': 'double',
        'decision_ms': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.client_id = kwargs.get('client_id', str())
        self.priority = kwargs.get('priority', int())
        self.accion = kwargs.get('accion', str())
        self.objeto = kwargs.get('objeto', str())
        self.color = kwargs.get('color', str())
        self.zona = kwargs.get('zona', str())
        self.frase = kwargs.get('frase', str())
        self.permitido = kwargs.get('permitido', bool())
        self.causa_decision = kwargs.get('causa_decision', str())
        self.degradado = kwargs.get('degradado', bool())
        self.fuente = kwargs.get('fuente', str())
        self.t_fin_habla = kwargs.get('t_fin_habla', float())
        self.captura_ms = kwargs.get('captura_ms', float())
        self.transcripcion_ms = kwargs.get('transcripcion_ms', float())
        self.decision_ms = kwargs.get('decision_ms', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.client_id != other.client_id:
            return False
        if self.priority != other.priority:
            return False
        if self.accion != other.accion:
            return False
        if self.objeto != other.objeto:
            return False
        if self.color != other.color:
            return False
        if self.zona != other.zona:
            return False
        if self.frase != other.frase:
            return False
        if self.permitido != other.permitido:
            return False
        if self.causa_decision != other.causa_decision:
            return False
        if self.degradado != other.degradado:
            return False
        if self.fuente != other.fuente:
            return False
        if self.t_fin_habla != other.t_fin_habla:
            return False
        if self.captura_ms != other.captura_ms:
            return False
        if self.transcripcion_ms != other.transcripcion_ms:
            return False
        if self.decision_ms != other.decision_ms:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def client_id(self):
        """Message field 'client_id'."""
        return self._client_id

    @client_id.setter
    def client_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'client_id' field must be of type 'str'"
        self._client_id = value

    @builtins.property
    def priority(self):
        """Message field 'priority'."""
        return self._priority

    @priority.setter
    def priority(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'priority' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'priority' field must be an unsigned integer in [0, 255]"
        self._priority = value

    @builtins.property
    def accion(self):
        """Message field 'accion'."""
        return self._accion

    @accion.setter
    def accion(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'accion' field must be of type 'str'"
        self._accion = value

    @builtins.property
    def objeto(self):
        """Message field 'objeto'."""
        return self._objeto

    @objeto.setter
    def objeto(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'objeto' field must be of type 'str'"
        self._objeto = value

    @builtins.property
    def color(self):
        """Message field 'color'."""
        return self._color

    @color.setter
    def color(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'color' field must be of type 'str'"
        self._color = value

    @builtins.property
    def zona(self):
        """Message field 'zona'."""
        return self._zona

    @zona.setter
    def zona(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'zona' field must be of type 'str'"
        self._zona = value

    @builtins.property
    def frase(self):
        """Message field 'frase'."""
        return self._frase

    @frase.setter
    def frase(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'frase' field must be of type 'str'"
        self._frase = value

    @builtins.property
    def permitido(self):
        """Message field 'permitido'."""
        return self._permitido

    @permitido.setter
    def permitido(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'permitido' field must be of type 'bool'"
        self._permitido = value

    @builtins.property
    def causa_decision(self):
        """Message field 'causa_decision'."""
        return self._causa_decision

    @causa_decision.setter
    def causa_decision(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'causa_decision' field must be of type 'str'"
        self._causa_decision = value

    @builtins.property
    def degradado(self):
        """Message field 'degradado'."""
        return self._degradado

    @degradado.setter
    def degradado(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'degradado' field must be of type 'bool'"
        self._degradado = value

    @builtins.property
    def fuente(self):
        """Message field 'fuente'."""
        return self._fuente

    @fuente.setter
    def fuente(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'fuente' field must be of type 'str'"
        self._fuente = value

    @builtins.property
    def t_fin_habla(self):
        """Message field 't_fin_habla'."""
        return self._t_fin_habla

    @t_fin_habla.setter
    def t_fin_habla(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 't_fin_habla' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 't_fin_habla' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._t_fin_habla = value

    @builtins.property
    def captura_ms(self):
        """Message field 'captura_ms'."""
        return self._captura_ms

    @captura_ms.setter
    def captura_ms(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'captura_ms' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'captura_ms' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._captura_ms = value

    @builtins.property
    def transcripcion_ms(self):
        """Message field 'transcripcion_ms'."""
        return self._transcripcion_ms

    @transcripcion_ms.setter
    def transcripcion_ms(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'transcripcion_ms' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'transcripcion_ms' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._transcripcion_ms = value

    @builtins.property
    def decision_ms(self):
        """Message field 'decision_ms'."""
        return self._decision_ms

    @decision_ms.setter
    def decision_ms(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'decision_ms' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'decision_ms' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._decision_ms = value


# Import statements for member types

# Member 'final_q'
import array  # noqa: E402, I100

# already imported above
# import builtins

# already imported above
# import math

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_Result(type):
    """Metaclass of message 'PickPlace_Result'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_Result')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__result
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__result
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__result
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__result
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__result

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_Result(metaclass=Metaclass_PickPlace_Result):
    """Message class 'PickPlace_Result'."""

    __slots__ = [
        '_success',
        '_message',
        '_final_q',
        '_error_fk_mm',
        '_voz_a_movimiento_ms',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
        'final_q': 'sequence<double>',
        'error_fk_mm': 'double',
        'voz_a_movimiento_ms': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('double')),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())
        self.final_q = array.array('d', kwargs.get('final_q', []))
        self.error_fk_mm = kwargs.get('error_fk_mm', float())
        self.voz_a_movimiento_ms = kwargs.get('voz_a_movimiento_ms', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        if self.final_q != other.final_q:
            return False
        if self.error_fk_mm != other.error_fk_mm:
            return False
        if self.voz_a_movimiento_ms != other.voz_a_movimiento_ms:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value

    @builtins.property
    def final_q(self):
        """Message field 'final_q'."""
        return self._final_q

    @final_q.setter
    def final_q(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'd', \
                "The 'final_q' array.array() must have the type code of 'd'"
            self._final_q = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -1.7976931348623157e+308 or val > 1.7976931348623157e+308) or math.isinf(val) for val in value)), \
                "The 'final_q' field must be a set or sequence and each value of type 'float' and each double in [-179769313486231570814527423731704356798070567525844996598917476803157260780028538760589558632766878171540458953514382464234321326889464182768467546703537516986049910576551282076245490090389328944075868508455133942304583236903222948165808559332123348274797826204144723168738177180919299881250404026184124858368.000000, 179769313486231570814527423731704356798070567525844996598917476803157260780028538760589558632766878171540458953514382464234321326889464182768467546703537516986049910576551282076245490090389328944075868508455133942304583236903222948165808559332123348274797826204144723168738177180919299881250404026184124858368.000000]"
        self._final_q = array.array('d', value)

    @builtins.property
    def error_fk_mm(self):
        """Message field 'error_fk_mm'."""
        return self._error_fk_mm

    @error_fk_mm.setter
    def error_fk_mm(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'error_fk_mm' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'error_fk_mm' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._error_fk_mm = value

    @builtins.property
    def voz_a_movimiento_ms(self):
        """Message field 'voz_a_movimiento_ms'."""
        return self._voz_a_movimiento_ms

    @voz_a_movimiento_ms.setter
    def voz_a_movimiento_ms(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'voz_a_movimiento_ms' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'voz_a_movimiento_ms' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._voz_a_movimiento_ms = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import math

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_Feedback(type):
    """Metaclass of message 'PickPlace_Feedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_Feedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__feedback
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_Feedback(metaclass=Metaclass_PickPlace_Feedback):
    """Message class 'PickPlace_Feedback'."""

    __slots__ = [
        '_queue_position',
        '_state',
        '_progress',
    ]

    _fields_and_field_types = {
        'queue_position': 'uint32',
        'state': 'string',
        'progress': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.queue_position = kwargs.get('queue_position', int())
        self.state = kwargs.get('state', str())
        self.progress = kwargs.get('progress', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.queue_position != other.queue_position:
            return False
        if self.state != other.state:
            return False
        if self.progress != other.progress:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def queue_position(self):
        """Message field 'queue_position'."""
        return self._queue_position

    @queue_position.setter
    def queue_position(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'queue_position' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'queue_position' field must be an unsigned integer in [0, 4294967295]"
        self._queue_position = value

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state' field must be of type 'str'"
        self._state = value

    @builtins.property
    def progress(self):
        """Message field 'progress'."""
        return self._progress

    @progress.setter
    def progress(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'progress' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'progress' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._progress = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_SendGoal_Request(type):
    """Metaclass of message 'PickPlace_SendGoal_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_SendGoal_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__send_goal__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__send_goal__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__send_goal__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__send_goal__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__send_goal__request

            from arm_broker_interfaces.action import PickPlace
            if PickPlace.Goal.__class__._TYPE_SUPPORT is None:
                PickPlace.Goal.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_SendGoal_Request(metaclass=Metaclass_PickPlace_SendGoal_Request):
    """Message class 'PickPlace_SendGoal_Request'."""

    __slots__ = [
        '_goal_id',
        '_goal',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'goal': 'arm_broker_interfaces/PickPlace_Goal',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['arm_broker_interfaces', 'action'], 'PickPlace_Goal'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from arm_broker_interfaces.action._pick_place import PickPlace_Goal
        self.goal = kwargs.get('goal', PickPlace_Goal())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.goal != other.goal:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def goal(self):
        """Message field 'goal'."""
        return self._goal

    @goal.setter
    def goal(self, value):
        if __debug__:
            from arm_broker_interfaces.action._pick_place import PickPlace_Goal
            assert \
                isinstance(value, PickPlace_Goal), \
                "The 'goal' field must be a sub message of type 'PickPlace_Goal'"
        self._goal = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_SendGoal_Response(type):
    """Metaclass of message 'PickPlace_SendGoal_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_SendGoal_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__send_goal__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__send_goal__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__send_goal__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__send_goal__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__send_goal__response

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_SendGoal_Response(metaclass=Metaclass_PickPlace_SendGoal_Response):
    """Message class 'PickPlace_SendGoal_Response'."""

    __slots__ = [
        '_accepted',
        '_stamp',
    ]

    _fields_and_field_types = {
        'accepted': 'boolean',
        'stamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.accepted = kwargs.get('accepted', bool())
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.accepted != other.accepted:
            return False
        if self.stamp != other.stamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def accepted(self):
        """Message field 'accepted'."""
        return self._accepted

    @accepted.setter
    def accepted(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'accepted' field must be of type 'bool'"
        self._accepted = value

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value


class Metaclass_PickPlace_SendGoal(type):
    """Metaclass of service 'PickPlace_SendGoal'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_SendGoal')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__pick_place__send_goal

            from arm_broker_interfaces.action import _pick_place
            if _pick_place.Metaclass_PickPlace_SendGoal_Request._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_SendGoal_Request.__import_type_support__()
            if _pick_place.Metaclass_PickPlace_SendGoal_Response._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_SendGoal_Response.__import_type_support__()


class PickPlace_SendGoal(metaclass=Metaclass_PickPlace_SendGoal):
    from arm_broker_interfaces.action._pick_place import PickPlace_SendGoal_Request as Request
    from arm_broker_interfaces.action._pick_place import PickPlace_SendGoal_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_GetResult_Request(type):
    """Metaclass of message 'PickPlace_GetResult_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_GetResult_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__get_result__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__get_result__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__get_result__request
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__get_result__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__get_result__request

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_GetResult_Request(metaclass=Metaclass_PickPlace_GetResult_Request):
    """Message class 'PickPlace_GetResult_Request'."""

    __slots__ = [
        '_goal_id',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_GetResult_Response(type):
    """Metaclass of message 'PickPlace_GetResult_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_GetResult_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__get_result__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__get_result__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__get_result__response
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__get_result__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__get_result__response

            from arm_broker_interfaces.action import PickPlace
            if PickPlace.Result.__class__._TYPE_SUPPORT is None:
                PickPlace.Result.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_GetResult_Response(metaclass=Metaclass_PickPlace_GetResult_Response):
    """Message class 'PickPlace_GetResult_Response'."""

    __slots__ = [
        '_status',
        '_result',
    ]

    _fields_and_field_types = {
        'status': 'int8',
        'result': 'arm_broker_interfaces/PickPlace_Result',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['arm_broker_interfaces', 'action'], 'PickPlace_Result'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.status = kwargs.get('status', int())
        from arm_broker_interfaces.action._pick_place import PickPlace_Result
        self.result = kwargs.get('result', PickPlace_Result())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.status != other.status:
            return False
        if self.result != other.result:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def status(self):
        """Message field 'status'."""
        return self._status

    @status.setter
    def status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'status' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'status' field must be an integer in [-128, 127]"
        self._status = value

    @builtins.property
    def result(self):
        """Message field 'result'."""
        return self._result

    @result.setter
    def result(self, value):
        if __debug__:
            from arm_broker_interfaces.action._pick_place import PickPlace_Result
            assert \
                isinstance(value, PickPlace_Result), \
                "The 'result' field must be a sub message of type 'PickPlace_Result'"
        self._result = value


class Metaclass_PickPlace_GetResult(type):
    """Metaclass of service 'PickPlace_GetResult'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_GetResult')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__action__pick_place__get_result

            from arm_broker_interfaces.action import _pick_place
            if _pick_place.Metaclass_PickPlace_GetResult_Request._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_GetResult_Request.__import_type_support__()
            if _pick_place.Metaclass_PickPlace_GetResult_Response._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_GetResult_Response.__import_type_support__()


class PickPlace_GetResult(metaclass=Metaclass_PickPlace_GetResult):
    from arm_broker_interfaces.action._pick_place import PickPlace_GetResult_Request as Request
    from arm_broker_interfaces.action._pick_place import PickPlace_GetResult_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_PickPlace_FeedbackMessage(type):
    """Metaclass of message 'PickPlace_FeedbackMessage'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace_FeedbackMessage')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__action__pick_place__feedback_message
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__action__pick_place__feedback_message
            cls._CONVERT_TO_PY = module.convert_to_py_msg__action__pick_place__feedback_message
            cls._TYPE_SUPPORT = module.type_support_msg__action__pick_place__feedback_message
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__action__pick_place__feedback_message

            from arm_broker_interfaces.action import PickPlace
            if PickPlace.Feedback.__class__._TYPE_SUPPORT is None:
                PickPlace.Feedback.__class__.__import_type_support__()

            from unique_identifier_msgs.msg import UUID
            if UUID.__class__._TYPE_SUPPORT is None:
                UUID.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class PickPlace_FeedbackMessage(metaclass=Metaclass_PickPlace_FeedbackMessage):
    """Message class 'PickPlace_FeedbackMessage'."""

    __slots__ = [
        '_goal_id',
        '_feedback',
    ]

    _fields_and_field_types = {
        'goal_id': 'unique_identifier_msgs/UUID',
        'feedback': 'arm_broker_interfaces/PickPlace_Feedback',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['unique_identifier_msgs', 'msg'], 'UUID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['arm_broker_interfaces', 'action'], 'PickPlace_Feedback'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from unique_identifier_msgs.msg import UUID
        self.goal_id = kwargs.get('goal_id', UUID())
        from arm_broker_interfaces.action._pick_place import PickPlace_Feedback
        self.feedback = kwargs.get('feedback', PickPlace_Feedback())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.goal_id != other.goal_id:
            return False
        if self.feedback != other.feedback:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def goal_id(self):
        """Message field 'goal_id'."""
        return self._goal_id

    @goal_id.setter
    def goal_id(self, value):
        if __debug__:
            from unique_identifier_msgs.msg import UUID
            assert \
                isinstance(value, UUID), \
                "The 'goal_id' field must be a sub message of type 'UUID'"
        self._goal_id = value

    @builtins.property
    def feedback(self):
        """Message field 'feedback'."""
        return self._feedback

    @feedback.setter
    def feedback(self, value):
        if __debug__:
            from arm_broker_interfaces.action._pick_place import PickPlace_Feedback
            assert \
                isinstance(value, PickPlace_Feedback), \
                "The 'feedback' field must be a sub message of type 'PickPlace_Feedback'"
        self._feedback = value


class Metaclass_PickPlace(type):
    """Metaclass of action 'PickPlace'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('arm_broker_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'arm_broker_interfaces.action.PickPlace')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_action__action__pick_place

            from action_msgs.msg import _goal_status_array
            if _goal_status_array.Metaclass_GoalStatusArray._TYPE_SUPPORT is None:
                _goal_status_array.Metaclass_GoalStatusArray.__import_type_support__()
            from action_msgs.srv import _cancel_goal
            if _cancel_goal.Metaclass_CancelGoal._TYPE_SUPPORT is None:
                _cancel_goal.Metaclass_CancelGoal.__import_type_support__()

            from arm_broker_interfaces.action import _pick_place
            if _pick_place.Metaclass_PickPlace_SendGoal._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_SendGoal.__import_type_support__()
            if _pick_place.Metaclass_PickPlace_GetResult._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_GetResult.__import_type_support__()
            if _pick_place.Metaclass_PickPlace_FeedbackMessage._TYPE_SUPPORT is None:
                _pick_place.Metaclass_PickPlace_FeedbackMessage.__import_type_support__()


class PickPlace(metaclass=Metaclass_PickPlace):

    # The goal message defined in the action definition.
    from arm_broker_interfaces.action._pick_place import PickPlace_Goal as Goal
    # The result message defined in the action definition.
    from arm_broker_interfaces.action._pick_place import PickPlace_Result as Result
    # The feedback message defined in the action definition.
    from arm_broker_interfaces.action._pick_place import PickPlace_Feedback as Feedback

    class Impl:

        # The send_goal service using a wrapped version of the goal message as a request.
        from arm_broker_interfaces.action._pick_place import PickPlace_SendGoal as SendGoalService
        # The get_result service using a wrapped version of the result message as a response.
        from arm_broker_interfaces.action._pick_place import PickPlace_GetResult as GetResultService
        # The feedback message with generic fields which wraps the feedback message.
        from arm_broker_interfaces.action._pick_place import PickPlace_FeedbackMessage as FeedbackMessage

        # The generic service to cancel a goal.
        from action_msgs.srv._cancel_goal import CancelGoal as CancelGoalService
        # The generic message for get the status of a goal.
        from action_msgs.msg._goal_status_array import GoalStatusArray as GoalStatusMessage

    def __init__(self):
        raise NotImplementedError('Action classes can not be instantiated')
