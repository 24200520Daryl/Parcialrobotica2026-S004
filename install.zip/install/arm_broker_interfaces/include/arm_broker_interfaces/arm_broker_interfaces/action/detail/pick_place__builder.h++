// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from arm_broker_interfaces:action/PickPlace.idl
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__BUILDER_HPP_
#define ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "arm_broker_interfaces/action/detail/pick_place__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_Goal_decision_ms
{
public:
  explicit Init_PickPlace_Goal_decision_ms(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_Goal decision_ms(::arm_broker_interfaces::action::PickPlace_Goal::_decision_ms_type arg)
  {
    msg_.decision_ms = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_transcripcion_ms
{
public:
  explicit Init_PickPlace_Goal_transcripcion_ms(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_decision_ms transcripcion_ms(::arm_broker_interfaces::action::PickPlace_Goal::_transcripcion_ms_type arg)
  {
    msg_.transcripcion_ms = std::move(arg);
    return Init_PickPlace_Goal_decision_ms(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_captura_ms
{
public:
  explicit Init_PickPlace_Goal_captura_ms(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_transcripcion_ms captura_ms(::arm_broker_interfaces::action::PickPlace_Goal::_captura_ms_type arg)
  {
    msg_.captura_ms = std::move(arg);
    return Init_PickPlace_Goal_transcripcion_ms(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_t_fin_habla
{
public:
  explicit Init_PickPlace_Goal_t_fin_habla(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_captura_ms t_fin_habla(::arm_broker_interfaces::action::PickPlace_Goal::_t_fin_habla_type arg)
  {
    msg_.t_fin_habla = std::move(arg);
    return Init_PickPlace_Goal_captura_ms(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_fuente
{
public:
  explicit Init_PickPlace_Goal_fuente(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_t_fin_habla fuente(::arm_broker_interfaces::action::PickPlace_Goal::_fuente_type arg)
  {
    msg_.fuente = std::move(arg);
    return Init_PickPlace_Goal_t_fin_habla(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_degradado
{
public:
  explicit Init_PickPlace_Goal_degradado(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_fuente degradado(::arm_broker_interfaces::action::PickPlace_Goal::_degradado_type arg)
  {
    msg_.degradado = std::move(arg);
    return Init_PickPlace_Goal_fuente(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_causa_decision
{
public:
  explicit Init_PickPlace_Goal_causa_decision(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_degradado causa_decision(::arm_broker_interfaces::action::PickPlace_Goal::_causa_decision_type arg)
  {
    msg_.causa_decision = std::move(arg);
    return Init_PickPlace_Goal_degradado(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_permitido
{
public:
  explicit Init_PickPlace_Goal_permitido(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_causa_decision permitido(::arm_broker_interfaces::action::PickPlace_Goal::_permitido_type arg)
  {
    msg_.permitido = std::move(arg);
    return Init_PickPlace_Goal_causa_decision(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_frase
{
public:
  explicit Init_PickPlace_Goal_frase(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_permitido frase(::arm_broker_interfaces::action::PickPlace_Goal::_frase_type arg)
  {
    msg_.frase = std::move(arg);
    return Init_PickPlace_Goal_permitido(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_zona
{
public:
  explicit Init_PickPlace_Goal_zona(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_frase zona(::arm_broker_interfaces::action::PickPlace_Goal::_zona_type arg)
  {
    msg_.zona = std::move(arg);
    return Init_PickPlace_Goal_frase(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_color
{
public:
  explicit Init_PickPlace_Goal_color(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_zona color(::arm_broker_interfaces::action::PickPlace_Goal::_color_type arg)
  {
    msg_.color = std::move(arg);
    return Init_PickPlace_Goal_zona(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_objeto
{
public:
  explicit Init_PickPlace_Goal_objeto(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_color objeto(::arm_broker_interfaces::action::PickPlace_Goal::_objeto_type arg)
  {
    msg_.objeto = std::move(arg);
    return Init_PickPlace_Goal_color(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_accion
{
public:
  explicit Init_PickPlace_Goal_accion(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_objeto accion(::arm_broker_interfaces::action::PickPlace_Goal::_accion_type arg)
  {
    msg_.accion = std::move(arg);
    return Init_PickPlace_Goal_objeto(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_priority
{
public:
  explicit Init_PickPlace_Goal_priority(::arm_broker_interfaces::action::PickPlace_Goal & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Goal_accion priority(::arm_broker_interfaces::action::PickPlace_Goal::_priority_type arg)
  {
    msg_.priority = std::move(arg);
    return Init_PickPlace_Goal_accion(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

class Init_PickPlace_Goal_client_id
{
public:
  Init_PickPlace_Goal_client_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_Goal_priority client_id(::arm_broker_interfaces::action::PickPlace_Goal::_client_id_type arg)
  {
    msg_.client_id = std::move(arg);
    return Init_PickPlace_Goal_priority(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_Goal>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_Goal_client_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_Result_voz_a_movimiento_ms
{
public:
  explicit Init_PickPlace_Result_voz_a_movimiento_ms(::arm_broker_interfaces::action::PickPlace_Result & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_Result voz_a_movimiento_ms(::arm_broker_interfaces::action::PickPlace_Result::_voz_a_movimiento_ms_type arg)
  {
    msg_.voz_a_movimiento_ms = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Result msg_;
};

class Init_PickPlace_Result_error_fk_mm
{
public:
  explicit Init_PickPlace_Result_error_fk_mm(::arm_broker_interfaces::action::PickPlace_Result & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Result_voz_a_movimiento_ms error_fk_mm(::arm_broker_interfaces::action::PickPlace_Result::_error_fk_mm_type arg)
  {
    msg_.error_fk_mm = std::move(arg);
    return Init_PickPlace_Result_voz_a_movimiento_ms(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Result msg_;
};

class Init_PickPlace_Result_final_q
{
public:
  explicit Init_PickPlace_Result_final_q(::arm_broker_interfaces::action::PickPlace_Result & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Result_error_fk_mm final_q(::arm_broker_interfaces::action::PickPlace_Result::_final_q_type arg)
  {
    msg_.final_q = std::move(arg);
    return Init_PickPlace_Result_error_fk_mm(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Result msg_;
};

class Init_PickPlace_Result_message
{
public:
  explicit Init_PickPlace_Result_message(::arm_broker_interfaces::action::PickPlace_Result & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Result_final_q message(::arm_broker_interfaces::action::PickPlace_Result::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_PickPlace_Result_final_q(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Result msg_;
};

class Init_PickPlace_Result_success
{
public:
  Init_PickPlace_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_Result_message success(::arm_broker_interfaces::action::PickPlace_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_PickPlace_Result_message(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_Result>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_Result_success();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_Feedback_progress
{
public:
  explicit Init_PickPlace_Feedback_progress(::arm_broker_interfaces::action::PickPlace_Feedback & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_Feedback progress(::arm_broker_interfaces::action::PickPlace_Feedback::_progress_type arg)
  {
    msg_.progress = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Feedback msg_;
};

class Init_PickPlace_Feedback_state
{
public:
  explicit Init_PickPlace_Feedback_state(::arm_broker_interfaces::action::PickPlace_Feedback & msg)
  : msg_(msg)
  {}
  Init_PickPlace_Feedback_progress state(::arm_broker_interfaces::action::PickPlace_Feedback::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_PickPlace_Feedback_progress(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Feedback msg_;
};

class Init_PickPlace_Feedback_queue_position
{
public:
  Init_PickPlace_Feedback_queue_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_Feedback_state queue_position(::arm_broker_interfaces::action::PickPlace_Feedback::_queue_position_type arg)
  {
    msg_.queue_position = std::move(arg);
    return Init_PickPlace_Feedback_state(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_Feedback>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_Feedback_queue_position();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_SendGoal_Request_goal
{
public:
  explicit Init_PickPlace_SendGoal_Request_goal(::arm_broker_interfaces::action::PickPlace_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Request goal(::arm_broker_interfaces::action::PickPlace_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Request msg_;
};

class Init_PickPlace_SendGoal_Request_goal_id
{
public:
  Init_PickPlace_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_SendGoal_Request_goal goal_id(::arm_broker_interfaces::action::PickPlace_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_PickPlace_SendGoal_Request_goal(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_SendGoal_Request>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_SendGoal_Request_goal_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_SendGoal_Response_stamp
{
public:
  explicit Init_PickPlace_SendGoal_Response_stamp(::arm_broker_interfaces::action::PickPlace_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Response stamp(::arm_broker_interfaces::action::PickPlace_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Response msg_;
};

class Init_PickPlace_SendGoal_Response_accepted
{
public:
  Init_PickPlace_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_SendGoal_Response_stamp accepted(::arm_broker_interfaces::action::PickPlace_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_PickPlace_SendGoal_Response_stamp(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_SendGoal_Response>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_SendGoal_Response_accepted();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_GetResult_Request_goal_id
{
public:
  Init_PickPlace_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::arm_broker_interfaces::action::PickPlace_GetResult_Request goal_id(::arm_broker_interfaces::action::PickPlace_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_GetResult_Request>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_GetResult_Request_goal_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_GetResult_Response_result
{
public:
  explicit Init_PickPlace_GetResult_Response_result(::arm_broker_interfaces::action::PickPlace_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_GetResult_Response result(::arm_broker_interfaces::action::PickPlace_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_GetResult_Response msg_;
};

class Init_PickPlace_GetResult_Response_status
{
public:
  Init_PickPlace_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_GetResult_Response_result status(::arm_broker_interfaces::action::PickPlace_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_PickPlace_GetResult_Response_result(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_GetResult_Response>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_GetResult_Response_status();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_PickPlace_FeedbackMessage_feedback
{
public:
  explicit Init_PickPlace_FeedbackMessage_feedback(::arm_broker_interfaces::action::PickPlace_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::PickPlace_FeedbackMessage feedback(::arm_broker_interfaces::action::PickPlace_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_FeedbackMessage msg_;
};

class Init_PickPlace_FeedbackMessage_goal_id
{
public:
  Init_PickPlace_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickPlace_FeedbackMessage_feedback goal_id(::arm_broker_interfaces::action::PickPlace_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_PickPlace_FeedbackMessage_feedback(msg_);
  }

private:
  ::arm_broker_interfaces::action::PickPlace_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::PickPlace_FeedbackMessage>()
{
  return arm_broker_interfaces::action::builder::Init_PickPlace_FeedbackMessage_goal_id();
}

}  // namespace arm_broker_interfaces

#endif  // ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__BUILDER_HPP_
