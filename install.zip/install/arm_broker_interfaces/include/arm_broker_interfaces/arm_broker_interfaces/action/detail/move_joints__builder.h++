// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from arm_broker_interfaces:action/MoveJoints.idl
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__ACTION__DETAIL__MOVE_JOINTS__BUILDER_HPP_
#define ARM_BROKER_INTERFACES__ACTION__DETAIL__MOVE_JOINTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "arm_broker_interfaces/action/detail/move_joints__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_Goal_q
{
public:
  explicit Init_MoveJoints_Goal_q(::arm_broker_interfaces::action::MoveJoints_Goal & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_Goal q(::arm_broker_interfaces::action::MoveJoints_Goal::_q_type arg)
  {
    msg_.q = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Goal msg_;
};

class Init_MoveJoints_Goal_priority
{
public:
  explicit Init_MoveJoints_Goal_priority(::arm_broker_interfaces::action::MoveJoints_Goal & msg)
  : msg_(msg)
  {}
  Init_MoveJoints_Goal_q priority(::arm_broker_interfaces::action::MoveJoints_Goal::_priority_type arg)
  {
    msg_.priority = std::move(arg);
    return Init_MoveJoints_Goal_q(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Goal msg_;
};

class Init_MoveJoints_Goal_client_id
{
public:
  Init_MoveJoints_Goal_client_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_Goal_priority client_id(::arm_broker_interfaces::action::MoveJoints_Goal::_client_id_type arg)
  {
    msg_.client_id = std::move(arg);
    return Init_MoveJoints_Goal_priority(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_Goal>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_Goal_client_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_Result_final_q
{
public:
  explicit Init_MoveJoints_Result_final_q(::arm_broker_interfaces::action::MoveJoints_Result & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_Result final_q(::arm_broker_interfaces::action::MoveJoints_Result::_final_q_type arg)
  {
    msg_.final_q = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Result msg_;
};

class Init_MoveJoints_Result_message
{
public:
  explicit Init_MoveJoints_Result_message(::arm_broker_interfaces::action::MoveJoints_Result & msg)
  : msg_(msg)
  {}
  Init_MoveJoints_Result_final_q message(::arm_broker_interfaces::action::MoveJoints_Result::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_MoveJoints_Result_final_q(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Result msg_;
};

class Init_MoveJoints_Result_success
{
public:
  Init_MoveJoints_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_Result_message success(::arm_broker_interfaces::action::MoveJoints_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MoveJoints_Result_message(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_Result>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_Result_success();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_Feedback_progress
{
public:
  explicit Init_MoveJoints_Feedback_progress(::arm_broker_interfaces::action::MoveJoints_Feedback & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_Feedback progress(::arm_broker_interfaces::action::MoveJoints_Feedback::_progress_type arg)
  {
    msg_.progress = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Feedback msg_;
};

class Init_MoveJoints_Feedback_state
{
public:
  explicit Init_MoveJoints_Feedback_state(::arm_broker_interfaces::action::MoveJoints_Feedback & msg)
  : msg_(msg)
  {}
  Init_MoveJoints_Feedback_progress state(::arm_broker_interfaces::action::MoveJoints_Feedback::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_MoveJoints_Feedback_progress(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Feedback msg_;
};

class Init_MoveJoints_Feedback_queue_position
{
public:
  Init_MoveJoints_Feedback_queue_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_Feedback_state queue_position(::arm_broker_interfaces::action::MoveJoints_Feedback::_queue_position_type arg)
  {
    msg_.queue_position = std::move(arg);
    return Init_MoveJoints_Feedback_state(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_Feedback>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_Feedback_queue_position();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_SendGoal_Request_goal
{
public:
  explicit Init_MoveJoints_SendGoal_Request_goal(::arm_broker_interfaces::action::MoveJoints_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Request goal(::arm_broker_interfaces::action::MoveJoints_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Request msg_;
};

class Init_MoveJoints_SendGoal_Request_goal_id
{
public:
  Init_MoveJoints_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_SendGoal_Request_goal goal_id(::arm_broker_interfaces::action::MoveJoints_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_MoveJoints_SendGoal_Request_goal(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_SendGoal_Request>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_SendGoal_Request_goal_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_SendGoal_Response_stamp
{
public:
  explicit Init_MoveJoints_SendGoal_Response_stamp(::arm_broker_interfaces::action::MoveJoints_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Response stamp(::arm_broker_interfaces::action::MoveJoints_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Response msg_;
};

class Init_MoveJoints_SendGoal_Response_accepted
{
public:
  Init_MoveJoints_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_SendGoal_Response_stamp accepted(::arm_broker_interfaces::action::MoveJoints_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_MoveJoints_SendGoal_Response_stamp(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_SendGoal_Response>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_SendGoal_Response_accepted();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_GetResult_Request_goal_id
{
public:
  Init_MoveJoints_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::arm_broker_interfaces::action::MoveJoints_GetResult_Request goal_id(::arm_broker_interfaces::action::MoveJoints_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_GetResult_Request>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_GetResult_Request_goal_id();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_GetResult_Response_result
{
public:
  explicit Init_MoveJoints_GetResult_Response_result(::arm_broker_interfaces::action::MoveJoints_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_GetResult_Response result(::arm_broker_interfaces::action::MoveJoints_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_GetResult_Response msg_;
};

class Init_MoveJoints_GetResult_Response_status
{
public:
  Init_MoveJoints_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_GetResult_Response_result status(::arm_broker_interfaces::action::MoveJoints_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_MoveJoints_GetResult_Response_result(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_GetResult_Response>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_GetResult_Response_status();
}

}  // namespace arm_broker_interfaces


namespace arm_broker_interfaces
{

namespace action
{

namespace builder
{

class Init_MoveJoints_FeedbackMessage_feedback
{
public:
  explicit Init_MoveJoints_FeedbackMessage_feedback(::arm_broker_interfaces::action::MoveJoints_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::arm_broker_interfaces::action::MoveJoints_FeedbackMessage feedback(::arm_broker_interfaces::action::MoveJoints_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_FeedbackMessage msg_;
};

class Init_MoveJoints_FeedbackMessage_goal_id
{
public:
  Init_MoveJoints_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJoints_FeedbackMessage_feedback goal_id(::arm_broker_interfaces::action::MoveJoints_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_MoveJoints_FeedbackMessage_feedback(msg_);
  }

private:
  ::arm_broker_interfaces::action::MoveJoints_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_broker_interfaces::action::MoveJoints_FeedbackMessage>()
{
  return arm_broker_interfaces::action::builder::Init_MoveJoints_FeedbackMessage_goal_id();
}

}  // namespace arm_broker_interfaces

#endif  // ARM_BROKER_INTERFACES__ACTION__DETAIL__MOVE_JOINTS__BUILDER_HPP_
