// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from arm_broker_interfaces:action/PickPlace.idl
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__STRUCT_H_
#define ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'client_id'
// Member 'accion'
// Member 'objeto'
// Member 'color'
// Member 'zona'
// Member 'frase'
// Member 'causa_decision'
// Member 'fuente'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_Goal
{
  rosidl_runtime_c__String client_id;
  /// 0 = mas alta ... 2 = mas baja (igual que MoveJoints)
  uint8_t priority;
  /// recoger_y_colocar | ir_inicio | desconocida
  rosidl_runtime_c__String accion;
  rosidl_runtime_c__String objeto;
  rosidl_runtime_c__String color;
  rosidl_runtime_c__String zona;
  rosidl_runtime_c__String frase;
  bool permitido;
  /// por que no es permitida (si permitido == false)
  rosidl_runtime_c__String causa_decision;
  bool degradado;
  /// laya | palabras_clave
  rosidl_runtime_c__String fuente;
  /// Marcas de tiempo / etapas previas (Parte C del examen)
  /// epoch s; 0.0 si la orden fue escrita
  double t_fin_habla;
  double captura_ms;
  double transcripcion_ms;
  double decision_ms;
} arm_broker_interfaces__action__PickPlace_Goal;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_Goal.
typedef struct arm_broker_interfaces__action__PickPlace_Goal__Sequence
{
  arm_broker_interfaces__action__PickPlace_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_Goal__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"
// Member 'final_q'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_Result
{
  bool success;
  rosidl_runtime_c__String message;
  rosidl_runtime_c__double__Sequence final_q;
  /// |FK(q alcanzado) - posicion solicitada| en el deposito
  double error_fk_mm;
  double voz_a_movimiento_ms;
} arm_broker_interfaces__action__PickPlace_Result;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_Result.
typedef struct arm_broker_interfaces__action__PickPlace_Result__Sequence
{
  arm_broker_interfaces__action__PickPlace_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'state'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_Feedback
{
  /// 0 = ejecutandose
  uint32_t queue_position;
  /// QUEUED | PERCEIVING | PLANNING | EXECUTING | GRIPPER
  rosidl_runtime_c__String state;
  double progress;
} arm_broker_interfaces__action__PickPlace_Feedback;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_Feedback.
typedef struct arm_broker_interfaces__action__PickPlace_Feedback__Sequence
{
  arm_broker_interfaces__action__PickPlace_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "arm_broker_interfaces/action/detail/pick_place__struct.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  arm_broker_interfaces__action__PickPlace_Goal goal;
} arm_broker_interfaces__action__PickPlace_SendGoal_Request;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_SendGoal_Request.
typedef struct arm_broker_interfaces__action__PickPlace_SendGoal_Request__Sequence
{
  arm_broker_interfaces__action__PickPlace_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} arm_broker_interfaces__action__PickPlace_SendGoal_Response;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_SendGoal_Response.
typedef struct arm_broker_interfaces__action__PickPlace_SendGoal_Response__Sequence
{
  arm_broker_interfaces__action__PickPlace_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} arm_broker_interfaces__action__PickPlace_GetResult_Request;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_GetResult_Request.
typedef struct arm_broker_interfaces__action__PickPlace_GetResult_Request__Sequence
{
  arm_broker_interfaces__action__PickPlace_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "arm_broker_interfaces/action/detail/pick_place__struct.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_GetResult_Response
{
  int8_t status;
  arm_broker_interfaces__action__PickPlace_Result result;
} arm_broker_interfaces__action__PickPlace_GetResult_Response;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_GetResult_Response.
typedef struct arm_broker_interfaces__action__PickPlace_GetResult_Response__Sequence
{
  arm_broker_interfaces__action__PickPlace_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "arm_broker_interfaces/action/detail/pick_place__struct.h"

/// Struct defined in action/PickPlace in the package arm_broker_interfaces.
typedef struct arm_broker_interfaces__action__PickPlace_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  arm_broker_interfaces__action__PickPlace_Feedback feedback;
} arm_broker_interfaces__action__PickPlace_FeedbackMessage;

// Struct for a sequence of arm_broker_interfaces__action__PickPlace_FeedbackMessage.
typedef struct arm_broker_interfaces__action__PickPlace_FeedbackMessage__Sequence
{
  arm_broker_interfaces__action__PickPlace_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_broker_interfaces__action__PickPlace_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ARM_BROKER_INTERFACES__ACTION__DETAIL__PICK_PLACE__STRUCT_H_
