// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_HPP_
#define ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_HPP_

#include "arm_broker_interfaces/action/detail/move_joints__struct.hpp"
#include "arm_broker_interfaces/action/detail/move_joints__builder.hpp"
#include "arm_broker_interfaces/action/detail/move_joints__traits.hpp"
#include "arm_broker_interfaces/action/detail/move_joints__type_support.hpp"

#endif  // ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_HPP_
