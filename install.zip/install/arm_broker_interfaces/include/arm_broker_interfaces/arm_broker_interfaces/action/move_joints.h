// generated from rosidl_generator_c/resource/idl.h.em
// with input from arm_broker_interfaces:action/MoveJoints.idl
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_H_
#define ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_H_

#include "arm_broker_interfaces/action/detail/move_joints__struct.h"
#include "arm_broker_interfaces/action/detail/move_joints__functions.h"
#include "arm_broker_interfaces/action/detail/move_joints__type_support.h"

#endif  // ARM_BROKER_INTERFACES__ACTION__MOVE_JOINTS_H_
