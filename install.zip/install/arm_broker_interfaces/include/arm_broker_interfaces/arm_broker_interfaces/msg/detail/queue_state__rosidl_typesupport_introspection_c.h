// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from arm_broker_interfaces:msg/QueueState.idl
// generated code does not contain a copyright notice

#ifndef ARM_BROKER_INTERFACES__MSG__DETAIL__QUEUE_STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define ARM_BROKER_INTERFACES__MSG__DETAIL__QUEUE_STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "arm_broker_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_arm_broker_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_broker_interfaces, msg, QueueState)();

#ifdef __cplusplus
}
#endif

#endif  // ARM_BROKER_INTERFACES__MSG__DETAIL__QUEUE_STATE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
